package PRACTICAL2;

public class Question5 {
        /** Main method */
        public static void main(String[] args) {

            GenericStack<Integer> stack = new GenericStack<>();
            for (int i = 0; i < 100; i++) {
                stack.push(i + 1);
            }

            System.out.println("Stack: ");
            for (int i = 1; !stack.isEmpty(); i++) {
                if (i % 10 == 0)
                    System.out.println(stack.pop());
                else
                    System.out.print(stack.pop() + " ");
            }
            System.out.println();
        }
    }

