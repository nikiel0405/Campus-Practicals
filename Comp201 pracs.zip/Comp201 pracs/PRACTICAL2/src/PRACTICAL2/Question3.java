package PRACTICAL2;

import java.util.Arrays;
import java.util.List;

public class Question3 {
    public static void main(String[] args) {

        Point[] points = new Point[100];
        for (int i = 0; i < points.length; i++) {
            points[i] = new Point((double)(Math.random() * 50),
                    (double)(Math.random() * 50));
        }

        Arrays.sort(points);
        List<Point> list1 = Arrays.asList(points);
        System.out.println("\nPoints in increasing order of their y-coordinates:");
        System.out.println(list1);

        Arrays.sort(points, new CompareX());
        List<Point> list2 = Arrays.asList(points);
        System.out.println("\nPoints in increasing order of their x-coordinates:");
        System.out.println(list2);
    }

}
