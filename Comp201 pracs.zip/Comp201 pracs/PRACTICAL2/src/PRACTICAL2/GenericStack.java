package PRACTICAL2;

public class GenericStack<E> {
    private E[] arr = (E[])new Object[10];
    private int size = 0;

    public int getSize() {
        return size;
    }

    public E peek() {
        return arr[size - 1];
    }

    public void push(E o) {
        if (size >= arr.length) {
            doubleList();
        }
        arr[size++] = o;
    }

    public E pop() {
        E o = arr[--size];
        return o;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    private void doubleList() {
        E[] tempList = (E[])new Object[arr.length * 2];
        for (int i = 0; i < arr.length; i++){
            tempList[i] = arr[i];
        }
        arr = tempList;
    }

    @Override
    public String toString() {
        return "stack: " + arr.toString();
    }
}
