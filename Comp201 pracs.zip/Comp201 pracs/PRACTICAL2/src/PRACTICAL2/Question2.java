package PRACTICAL2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Question2{

    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a file name: ");
        File file = new File(input.next().trim());

        Scanner scan = new Scanner(file);
        ArrayList<String> text = new ArrayList<String>();

        while (scan.hasNext()){
            text.add(scan.next());
        }

        Map<String, Integer> wordsCount = new HashMap<>();
        for (String word: text) {
            String key = word.toLowerCase();

            if (key.length() > 0) {
                if (!wordsCount.containsKey(key)) {
                    wordsCount.put(key, 1);
                }
                else {
                    /*int value = wordsCount.get(key);
                    value++;
                    wordsCount.put(key, value);*/


                    wordsCount.put(key, wordsCount.get(key)+1);
                }
            }
        }

        ArrayList<WordOccurrence> word = new ArrayList<>();

        for (Map.Entry<String, Integer> entry: wordsCount.entrySet())
            word.add(new WordOccurrence(entry.getKey(), entry.getValue()));

        Collections.sort(word);
        System.out.println(word);
    }
}
