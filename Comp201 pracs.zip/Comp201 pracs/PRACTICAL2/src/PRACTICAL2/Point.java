package PRACTICAL2;

public class Point implements Comparable<Point> {
    private double x;
    private double y;

    Point() {}

    Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public int compareTo(Point point) {
        if (y == point.getY()) {
            if (x > point.getX())
                return 1;
            else if (x < point.getX())
                return -1;
            else
                return 0;
        }
        else if (y > point.getY())
            return 1;
        else
            return -1;
    }
    public String toString() {
        return "(" + x + ", " + y + ")";
}}
