package PRACTICAL2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Question1 {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a java file name: ");
        File file = new File(input.next().trim());

        Scanner scan = new Scanner(file);
        String[] Keyword = {"abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
                "continue", "default", "do", "double", "else", "enum", "extends", "for", "final", "finally", "float", "goto",
                "if", "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "package", "private",
                "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
                "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false", "null"};
        Set<String> key = new HashSet<String>(Arrays.asList(Keyword));
        int count = 0;

        while (scan.hasNext()){
            String word = scan.next();
            if (word.equals("//")){
                scan.next();
            } else if (word.equals("/*")){
                while (scan.hasNext()){
                    if (!scan.next().equals("*/")){
                        scan.next();
                    }
                }
            } else if (key.contains(word)) {
                count++;
            }
        }

        System.out.println("\n" + "The number of keywords in this file: " + count);


    }
}
