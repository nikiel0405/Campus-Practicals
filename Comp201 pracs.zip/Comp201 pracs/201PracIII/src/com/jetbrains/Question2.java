package com.jetbrains;


public class Question2 {
    public static void main(String[] args){
        String[] arr1 = {"Tom","George","Peter","Jean","Jane"};
        String[] arr2 = {"Tom","George","Michael","Michelle","Daniel"};
        MyArrayList<String> list1 = new MyArrayList<>(arr1);
        MyArrayList list2 = new MyArrayList<>(arr2);

        list1.addAll(list2);
        System.out.println("List 1:\t" +list1+"\nList 2:\t"+ list2);

        list1 = new MyArrayList<>(arr1);
        list2 = new MyArrayList<>(arr2);
        list1.removeAll(list2);
        System.out.println("\nList 1:\t" +list1+"\nList 2:\t"+ list2);

        list1 = new MyArrayList<>(arr1);
        list2 = new MyArrayList<>(arr2);
        list1.retainAll(list2);
        System.out.println("\nList 1:\t" +list1+"\nList 2:\t"+ list2);



    }
}
