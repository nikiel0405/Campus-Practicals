package com.jetbrains;

public class MyQueue<E> extends MyLinkedList<E>{

    public void enqueue(E element){
        if(size == 0){
            addFirst(element);
        }
        else{
            addLast(element);
        }
    }

    public E dequeue(){
        if(size == 0)
            return null;

        E obj = getFirst();
        removeFirst();

        return obj;
    }

    public int getSize(){
        return size();
    }

    public E peek(){
        int len = getSize();
        if (len == 0)
            return null;

        return get(len - 1);
    }

}

