package com.jetbrains;

public class Question4 {
    public static void main(String[] args){
        String[] arr2 = {"Tom","George","Michael","Michelle","Daniel"};
        MyCircularLinkedList<String> clist2 = new MyCircularLinkedList(arr2);


        clist2.addFirst("Lilly");
        System.out.println("\n\nlist2 after addFirst:" + clist2);

        clist2.addLast("Ron");
        System.out.println("list2 after addLast:" + clist2);

        clist2.removeFirst();
        System.out.println("list2 after removeFirst:" + clist2);

        clist2.removeLast();
        System.out.println("list2 after removeLast:" + clist2);
    }
}
