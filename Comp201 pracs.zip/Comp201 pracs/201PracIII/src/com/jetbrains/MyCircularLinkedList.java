package com.jetbrains;

public class MyCircularLinkedList<E> extends MyAbstractList<E> {
    private Node<E> head, tail;

    /** Create a default list */
    public MyCircularLinkedList() {
    }

    /** Create a list from an array of objects */
    public MyCircularLinkedList(E[] objects) {
        super(objects);
        tail.next= head;
    }

    /** Return the head element in the list */
    public E getFirst() {
        if (size == 0) {
            return null;
        }
        else {
            return head.element;
        }
    }

    /** Return the last element in the list */
    public E getLast() {
        if (size == 0) {
            return null;
        }
        else {
            return tail.element;
        }
    }

    /** Add an element to the beginning of the list */
    public void addFirst(E e) {
        head= new Node<E>(e, head); // Create a new node
        if (tail == null){ // the new node is the only node in list
            tail = head;
            tail.next = head;
        }
        else{
            tail.next=head;
        }
        size++; // Increase list size
    }


    // This is only meant to test if mya addFirst and addLast are working fine
    public void printFirstNode(){
        System.out.println(tail.next.element);
        //return tail.next.next.element;
    }


    /** Add an element to the end of the list */
    public void addLast(E e) {
        Node<E> newNode = new Node<E>(e,head); // Create a new nodefor element e

        if (tail == null) {
            head = tail = newNode; // The new node is the only node in list
            tail.next = tail;
        }
        else {
            tail.next = newNode; // Link the new with the last node
            tail = tail.next; // tail now points to the last node
            //tail.next= head;
        }

        size++; // Increase size
    }


    @Override /** Add a new element at the specified index
     * in this list. The index of the head element is 0 */
    public void add(int index, E e) {

        checkIndex(index);

        if (index == 0) {

            addFirst(e);

        }
        else if (index >= size) {

            addLast(e);
        }
        else {

            Node<E> current = head;
            for (int i = 0; i < index; i++) {
                current = current.next;
            }
            System.out.println(index);
            Node<E> temp = current.next;

            current.next = new Node<E>(e, null);
            (current.next).next = temp;
            size++;
        }
    }

    /** Remove the head node and
     *  return the object that is contained in the removed node. */
    public E removeFirst() {
        if (size == 0) {
            return null;
        }
        else {
            Node<E> temp = head;
            head = head.next;
            tail.next=head;
            size--;
            if (head == null) {
                tail = null;
            }
            return temp.element;
        }
    }

    /** Remove the last node and
     * return the object that is contained in the removed node. */
    public E removeLast() {
        if (size == 0) {
            return null;
        }
        else if (size == 1) {
            Node<E> temp = head;
            head = tail = null;
            size = 0;
            return temp.element;
        }
        else {
            Node<E> current = head;

            for (int i = 0; i < size - 2; i++) {
                current = current.next;
            }

            Node<E> temp = tail;
            tail = current;
            tail.next = head;
            size--;
            return temp.element;
        }
    }

    @Override /** Remove the element at the specified position in this
     *  list. Return the element that was removed from the list. */
    public E remove(int index) {
        checkIndex(index);

        if (index < 0 || index >= size) {

            return null;
        }
        else if (index == 0) {

            return removeFirst();
        }
        else if (index == size - 1) {

            return removeLast();
        }
        else {
            Node<E> previous = head;
            for (int i = 1; i < index; i++) {
                previous = previous.next;
            }

            Node<E> current = previous.next;
            previous.next = current.next;
            size--;
            return current.element;
        }
    }

    @Override /** Override toString() to return elements in the list */
    public String toString() {
        StringBuilder result = new StringBuilder("[");

        Node<E> current = head;
        for (int i = 0; i < size; i++) {
            result.append(current.element);
            current = current.next;
            if (i< size-1) {
                result.append(", "); // Separate two elements with a comma
            }
            else {
                result.append("]"); // Insert the closing ] in the string
            }
        }

        return result.toString();
    }

    @Override /** Clear the list */
    public void clear() {
        size = 0;
        head = tail = null;
    }

    @Override /** Return true if this list contains the element e */
    public boolean contains(E e) {
        for(Node current = head; current.next!=head; current = current.next)
        {
            if(current.element.equals(e))
            {
                return true;
            }
        }
        return false;
    }

    @Override /** Return the element at the specified index */
    public E get(int index) {
        Node current = head;
        for(int i= 0; i< index;i++)
            current = current.next;
        return (E)current.element;
    }

    @Override /** Return the index of the head matching element in
     *  this list. Return -1 if no match. */
    public int indexOf(E e) {
        int i=0;
        for(Node current = head; current!=head; current = current.next){
            if(e==current.element)
                return i;
            i++;
        }
        if (i < 0 || i > size-1 )
            return -1;
        else
            return i;
    }

    @Override /** Return the index of the last matching element in
     *  this list. Return -1 if no match. */
    public int lastIndexOf(E e) {
        int i=0;
        int n = -1;
        // for(Node current = head; current!=head; current = current.next){
        Node current = head;
        do {
            if(e==current.element)
                n=i;
            i++;
            current=current.next;
        } while (current!=head);
        return n;
    }

    @Override /** Replace the element at the specified position
     *  in this list with the specified element. */
    public E set(int index, E e) {
        if (index < 0 || index > size +1)
        {
            throw new IndexOutOfBoundsException
                    ("Index: " + index + ", Size: " + size);
        }
        else{
            Node current = head;
            for(int i= 0; i< index -1;i++)
                current = current.next;
            current.next = new Node(e, (current.next).next);
        }
        return e;
    }

    @Override /** Override iterator() defined in Iterable */
    public java.util.Iterator<E> iterator() {
        return new LinkedListIterator();
    }

    private void checkIndex(int index) {
        if (index < 0 || index > size +1)
            throw new IndexOutOfBoundsException
                    ("Index: " + index + ", Size: " + size);
    }

    @Override
    public boolean retainAll(MyList<E> otherList) {
        MyCircularLinkedList list = (MyCircularLinkedList)otherList;
        boolean changed = false;
        for(Node current= head; current!= null; current = current.next)
        {
            if (!list.contains(current.element)){
                remove((E)current.element);
                changed = true;
            }
        }
        return changed;
    }
    private class Node<E>{
        E element;
        Node next;
        public Node() {
            next=null;

        }
        public  Node(E el, Node n){
            element= el;
            next = n;
        }

    }

    private class LinkedListIterator
            implements java.util.Iterator<E> {
        private Node<E> current = head; // Current index

        @Override
        public boolean hasNext() {
            return (current != null);
        }

        @Override
        public E next() {
            E e = current.element;
            current = current.next;
            return e;
        }

        @Override
        public void remove() {
            System.out.println("Implementation left as an exercise");
        }
    }
}

