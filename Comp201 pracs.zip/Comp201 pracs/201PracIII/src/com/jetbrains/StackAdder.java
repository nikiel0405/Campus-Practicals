package com.jetbrains;

import java.util.Scanner;

public class StackAdder {

    public static void main(String[] args) {
        GenericStack<Integer> stack1 = new GenericStack<>();
        GenericStack<Integer> stack2 = new GenericStack<>();
        GenericStack<Integer> resultStack = new GenericStack<>();

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the first number: ");
        int num1 = sc.nextInt();
        System.out.println("Enter the second number: ");
        int num2 = sc.nextInt();
        sc.close();
        addToStack(num1, stack1);
        addToStack(num2, stack2);
        System.out.println("Your first number is:\t" + stack1 + "\nYour second number is:\t" + stack2);
        sumNumbers(stack1, stack2, resultStack);

        System.out.println("Answer:\t"+resultStack);
    }

    private static void addToStack(int num, GenericStack<Integer> stack){
        String s = ""+num;

        int divider = (int) Math.pow(10, s.length()-1);

        for (int i = 0; i < s.length(); i++){
            int temp = num/divider;
            stack.push(temp);
            num%=divider;
            divider/=10;
        }
    }

    private static void sumNumbers(GenericStack<Integer> stack1, GenericStack<Integer> stack2, GenericStack<Integer> resultStack){
        int size = Math.max(stack1.getSize(), stack2.getSize());
        int num1 = 0;
        int num2 = 0;
        int carryOver = 0;
        int sum = 0;

        for (int i = 0; i < size; i++){
            if (stack1.getSize() != 0)
                num1 = stack1.pop();
            else
                num1 = 0;

            if (stack2.getSize() != 0)
                num2 = stack2.pop();
            else
                num2 = 0;

            sum = num1+num2+carryOver;
            carryOver = sum/10;
            sum %= 10;
            resultStack.push(sum);
        }

    }
}
