package com.jetbrains;

public abstract class MyAbstractList<E> implements MyList<E> {
    protected int size = 0; // The size of the list

    /** Create a default list */
    protected MyAbstractList() {
    }

    /** Create a list from an array of objects */
    protected MyAbstractList(E[] objects) {
        for (int i = 0; i < objects.length; i++)
            add(objects[i]);
    }
    //additional methods implementation
    public boolean addAll(MyList<E> list){
        for (int i = 0; i < list.size() ; i++) {
            add(list.get(i));
        }
        if(list.size() > 0){
            return true;
        }
        return false;
    }

    public boolean removeAll(MyList<E> list){
        boolean changed = false;
        for (int i = 0; i < list.size(); i++) {
            if(remove(list.get(i))){
                changed = true;
            }
        }
        return changed;
    }

    public boolean retainAll(MyList<E> list){
        boolean changed = false;
        for (int i = 0; i < this.size() ; ) {
            if(!list.contains(this.get(i))){
                this.remove(this.get(i));
                changed = true;
            }else{i++;}
        }
        return changed;
    }
    //end

    @Override /** Add a new element at the end of this list */
    public void add(E e) {
        add(size, e);
    }

    @Override /** Return true if this list contains no elements */
    public boolean isEmpty() {
        return size == 0;
    }

    @Override /** Return the number of elements in this list */
    public int size() {
        return size;
    }

    @Override /** Remove the first occurrence of the element e
     *  from this list. Shift any subsequent elements to the left.
     *  Return true if the element is removed. */
    public boolean remove(E e) {
        if (indexOf(e) >= 0) {
            remove(indexOf(e));
            return true;
        }
        else
            return false;
    }
}
