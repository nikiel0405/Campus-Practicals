package com.jetbrains;

import java.util.Iterator;

public class Main {

    public static void main(String[] args) {
	// write your code here
        MyTwoWayLinkedList<String> list = new MyTwoWayLinkedList<>();
        list.add("asdf");
        list.add("1234");
        list.add("fffff");
        list.add("44556699");
        list.add("1234");
        list.add("ccsdcd");
        list.add("1234");
        list.add("1234sssss");
        System.out.println(list);
        list.remove(3);
        System.out.println(list);
        list.removeLast();
        System.out.println(list);
        System.out.println(list.contains("asd"));
        System.out.println(list.contains("fffff"));
        System.out.println();
        System.out.println(list.get(3));
        System.out.println(list.get(5));
        System.out.println();
        System.out.println(list.indexOf("44556699"));
        System.out.println(list.indexOf("asdf"));
        System.out.println(list.indexOf("123"));
        System.out.println(list.indexOf("1234"));
        System.out.println();
        System.out.println(list.lastIndexOf("44556699"));
        System.out.println(list.lastIndexOf("1234"));
        System.out.println(list.lastIndexOf("1234sssssssss"));
        System.out.println();
        System.out.println(list.set(0, "987654321"));
        System.out.println(list.set(5, "tratata"));
        System.out.println(list);
        for (Iterator<String> iterator = list.iterator(); iterator.hasNext();) {
            iterator.remove();
        }
        System.out.println(list);











    }
}
