package com.jetbrains;

public class Question5 {
    public static void main(String[] args){
        MyQueue<String> queue = new MyQueue<String>();

        queue.enqueue("John");
        queue.enqueue("Jack");
        queue.enqueue("James");
        queue.enqueue("July");
        queue.enqueue("Janice");

        System.out.println("\n\nQueue:\t"+queue);
        System.out.println("Size:\t"+queue.getSize());
        System.out.println("Dequeue:"+queue.dequeue());
    }
}
