package com.jetbrains;

public class GenericStack<E> extends MyTwoWayLinkedList<E>{
    public GenericStack(){

    }

    public int getSize(){
        return size;
    }

    public E peek(){
        int len = getSize();
        if (len == 0)
            return null;

        return get(len - 1);
    }

    public E pop(){

        return removeLast();
    }

    public void push(E element){
        addLast(element);
    }

    public boolean isEmpty(){
        return getSize() == 0;
    }

}
