package com.company;

import java.util.Scanner;
import java.util.Stack;

public class Question7 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a comand line :");
        char [] c ={'*','+','-','/'};
        String line = sc.nextLine();
        double no1 = 0;
        double no2 = 0;
        System.out.println(line);
        Stack<String>  stack = new Stack<String>();


        for(int i = line.length() -1; i>=0;i--){
            if (Character.toString(line.charAt(i)) == "+" ) {

            }
            else if(Character.toString(line.charAt(i)) == "*" ){

            }
            else if(Character.toString(line.charAt(i)) == "-"){

            }
            else if(Character.toString(line.charAt(i)) == "/"){

            }
            else{
                stack.push(Character.toString(line.charAt(i)));

            }
        }
        System.out.println(stack);
    }
}
