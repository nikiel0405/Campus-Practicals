package com.company;

import java.util.LinkedList;
import java.util.ListIterator;

public class Main {

    public static void main(String[] args) {
	// write your code here
        LinkedList<Integer> intList = new LinkedList<Integer>();
        for(int x = 0; x<100000; x++){
            intList.add((int) (Math.random()*100));
        }

        //classsic for Loop
        System.out.println("CLASSIC FOR LOOP");
        long Start = System.currentTimeMillis();
        for(int i = 0; i<100000; i++){
           System.out.print( intList.get(i)+ " ");
        }
        System.out.println();
        long fin = System.currentTimeMillis();
        System.out.println("Time taken for classic for loop is"+ (fin-Start)+" milliseconds");
        System.out.println();

        System.out.println("THIS IS FOR ITERATED LOOP");
        //iterator loop
        Start = System.currentTimeMillis();
        ListIterator<Integer>  listy = intList.listIterator();

        while (listy.hasNext()){
            System.out.print(listy.next()+" ");
        }
        System.out.println();
        fin = System.currentTimeMillis();
        System.out.println("Time taken for iterated loop is"+ (fin-Start)+" milliseconds");


        System.out.println();
        System.out.println("THIS IS FOR ENHANCED FOR LOOP");
        //enhanced loop
        Start = System.currentTimeMillis();
        for(Object element : intList){
            System.out.print(element.toString()+ " ");
        }
        fin = System.currentTimeMillis();
        System.out.println();
        System.out.println("Time taken for enhanced loop is"+ (fin-Start)+" milliseconds");





    }
}
