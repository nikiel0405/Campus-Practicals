package com.company;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;

public class Question2 {

    public static void main(String[] args){
        Queue<Integer> Qu=new LinkedList<Integer>();
        for(int i = 0; i<10;i++){
            Qu.offer((int)(Math.random()*100));
        }
        System.out.println(Collections.max(Qu)+"Is the highest value");
    }
}
