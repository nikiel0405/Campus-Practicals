package com.company;

import java.util.PriorityQueue;

public class Question3 {

    public static void main(String[] args)throws CloneNotSupportedException{
        MyPriorityQueue<Integer> mp = new MyPriorityQueue<Integer>();
        mp.offer(1);
        mp.offer(2);
        mp.offer(4);

        MyPriorityQueue<Integer> mp1 = null;
        mp1 = (MyPriorityQueue<Integer>)(mp.clone());
        System.out.println(mp1);
    }

    static class MyPriorityQueue<E> extends PriorityQueue<E> implements Cloneable{

        public Object clone() throws CloneNotSupportedException{
            MyPriorityQueue<E>  clone = new MyPriorityQueue<>();
            this.forEach(clone::offer);
            return clone;
        }
    }
}
