package com.company;

import java.util.*;

public class Question4 {

    public static void main(String[] args) {
        PriorityQueue<String> list1 = new PriorityQueue<>(6);
        PriorityQueue<String> list2 = new PriorityQueue<>(5);
        List<String> Union = new LinkedList<>();
        PriorityQueue<String> Intersection = new PriorityQueue<>();
        List<String> Difference = new LinkedList<>();
        list1.offer("George");
        list1.offer("Jim");
        list1.offer("John");
        list1.offer("Blake");
        list1.offer("Kevin");
        list1.offer("Michael");

        list2.offer("George");
        list2.offer("Katie");
        list2.offer("Kevin");
        list2.offer("Michelle");
        list2.offer("Ryan");

        for(String x : list1){
            if(list2.contains(x)){
                Intersection.add(x);
            }
        }


        for(String z: list1){
            Union.add(z);
        }

        for(String t : list2){
            Union.add(t);
        }

        for(String u :Union){
            if(!Intersection.contains(u)){
                Difference.add(u);
            }
        }

        System.out.println(Union+"");
        System.out.println(Intersection);
        System.out.println(Difference);


    }


}
