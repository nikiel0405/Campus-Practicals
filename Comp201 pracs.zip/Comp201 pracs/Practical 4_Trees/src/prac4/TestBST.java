package prac4;

public class TestBST {
	public static void main(String[] args) {
		// Create a BST
		BST<String> tree = new BST<String>();
		tree.insert("Jeff");
		tree.insert("Seth");
		tree.insert("McFarlen");
		tree.insert("Robert");
		tree.insert("Dumbi");
		tree.insert("Bob");
		tree.insert("Sam");

		// Traverse tree

		System.out.print("\n***Iterative Inorder (sorted: ");
		tree.iterativeInorder();
		System.out.print("\nPostorder: ");
		tree.postorder();
		System.out.print("\n***Iterative Preorder: ");
		tree.iterativePreorder();
		System.out.println("\n***Breadth first traversal: ");
		tree.breadthFirst();
		System.out.print("\nThe number of nodes is " + tree.getSize());
		System.out.print("\nThe height is: " +tree.height());

		// Search for an element
		System.out.print("\nIs Tyreen in the tree? " + tree.recursiveSearch("Tyreen",tree.getRoot()));

		// Get a path from the root to Qamar
		System.out.print("\nA path from the root to Qamar is: ");
		java.util.ArrayList<BST.TreeNode<String>> path = tree.path("Qamar");
		for (int i = 0; path != null && i < path.size(); i++)
			System.out.print(path.get(i).element + " ");

		Integer[] numbers = { 2, 4, 3, 1, 8, 5, 6, 7 };
		BST<Integer> intTree = new BST<Integer>(numbers);
		System.out.print("\nInorder (sorted): ");
		intTree.inorder();

		System.out.print("\nThe mirror of the Binary tree is : ");
		tree.mirrorOf(tree.getRoot());
	}
}