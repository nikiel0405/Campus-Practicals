package prac4;

import java.util.Comparator;

import prac3.GenericQueue;
import prac3.GenericStack;

public class BST<E extends Comparable<E>> extends AbstractTree<E> {
	protected TreeNode<E> root;
	protected int size = 0;
	@SuppressWarnings("unused")
	private Comparator<? super E> comparator;

	/** Create a default binary tree */
	public BST() {
	}

	/** Create a binary tree from an array of objects */
	public BST(E[] objects) {
		for (int i = 0; i < objects.length; i++)
			insert(objects[i]);
	}

	public BST(Comparator<? super E> comparator) {
		this.comparator = comparator;
	}

	@Override /** Returns true if the element is in the tree */
	public boolean search(E e) {
		TreeNode<E> current = root; // Start from the root

		while (current != null) {
			if (e.compareTo(current.element) < 0) {
				current = current.left;
			} else if (e.compareTo(current.element) > 0) {
				current = current.right;
			} else // element matches current.element
				return true; // Element is found
		}

		return false;
	}

	@Override /**
				 * Insert element o into the binary tree Return true if the
				 * element is inserted successfully
				 */
	public boolean insert(E e) {
		if (root == null)
			root = createNewNode(e); // Create a new root
		else {
			// Locate the parent node
			TreeNode<E> parent = null;
			TreeNode<E> current = root;
			while (current != null)
				if (e.compareTo(current.element) < 0) {
					parent = current;
					current = current.left;
				} else if (e.compareTo(current.element) > 0) {
					parent = current;
					current = current.right;
				} else
					return false; // Duplicate node not inserted

			// Create the new node and attach it to the parent node
			if (e.compareTo(parent.element) < 0)
				parent.left = createNewNode(e);
			else
				parent.right = createNewNode(e);
		}

		size++;
		return true; // Element inserted
	}

	protected TreeNode<E> createNewNode(E e) {
		return new TreeNode<E>(e);
	}

	@Override /** Inorder traversal from the root */
	public void inorder() {
		inorder(root);
	}

	/** Inorder traversal from a subtree */
	protected void inorder(TreeNode<E> root) {
		if (root == null)
			return;
		inorder(root.left);
		System.out.print(root.element + " ");
		inorder(root.right);
	}

	@Override /** Postorder traversal from the root */
	public void postorder() {
		postorder(root);
	}

	/** Postorder traversal from a subtree */
	protected void postorder(TreeNode<E> root) {
		if (root == null)
			return;
		postorder(root.left);
		postorder(root.right);
		System.out.print(root.element + " ");
	}

	@Override /** Preorder traversal from the root */
	public void preorder() {
		preorder(root);
	}

	/** Preorder traversal from a subtree */
	protected void preorder(TreeNode<E> root) {
		if (root == null)
			return;
		System.out.print(root.element + " ");
		preorder(root.left);
		preorder(root.right);
	}

	/**
	 * This inner class is static, because it does not access any instance
	 * members defined in its outer class
	 */
	public static class TreeNode<E extends Comparable<E>> {
		protected E element;
		protected TreeNode<E> left;
		protected TreeNode<E> right;

		public TreeNode(E e) {
			element = e;
		}
	}

	@Override /** Get the number of nodes in the tree */
	public int getSize() {
		return size;
	}

	/** Returns the root of the tree */
	public TreeNode<E> getRoot() {
		return root;
	}

	/** Returns a path from the root leading to the specified element */
	public java.util.ArrayList<TreeNode<E>> path(E e) {
		java.util.ArrayList<TreeNode<E>> list = new java.util.ArrayList<TreeNode<E>>();
		TreeNode<E> current = root; // Start from the root

		while (current != null) {
			list.add(current); // Add the node to the list
			if (e.compareTo(current.element) < 0) {
				current = current.left;
			} else if (e.compareTo(current.element) > 0) {
				current = current.right;
			} else
				break;
		}

		return list; // Return an array of nodes
	}

	@Override /**
				 * Delete an element from the binary tree. Return true if the
				 * element is deleted successfully Return false if the element
				 * is not in the tree
				 */
	public boolean delete(E e) {
		// Locate the node to be deleted and also locate its parent node
		TreeNode<E> parent = null;
		TreeNode<E> current = root;
		while (current != null) {
			if (e.compareTo(current.element) < 0) {
				parent = current;
				current = current.left;
			} else if (e.compareTo(current.element) > 0) {
				parent = current;
				current = current.right;
			} else
				break; // Element is in the tree pointed at by current
		}

		if (current == null)
			return false; // Element is not in the tree

		// Case 1: current has no left children
		if (current.left == null) {
			// Connect the parent with the right child of the current node
			if (parent == null) {
				root = current.right;
			} else {
				if (e.compareTo(parent.element) < 0)
					parent.left = current.right;
				else
					parent.right = current.right;
			}
		} else {
			// Case 2: The current node has a left child
			// Locate the rightmost node in the left subtree of
			// the current node and also its parent
			TreeNode<E> parentOfRightMost = current;
			TreeNode<E> rightMost = current.left;

			while (rightMost.right != null) {
				parentOfRightMost = rightMost;
				rightMost = rightMost.right; // Keep going to the right
			}

			// Replace the element in current by the element in rightMost
			current.element = rightMost.element;

			// Eliminate rightmost node
			if (parentOfRightMost.right == rightMost)
				parentOfRightMost.right = rightMost.left;
			else
				// Special case: parentOfRightMost == current
				parentOfRightMost.left = rightMost.left;
		}

		size--;
		return true; // Element inserted
	}

	public boolean deleteByMerging(E e) {
	    // Locate the node to be deleted and also locate its parent node
	    TreeNode<E> parent = null;
	    TreeNode<E> current = root;
	    while (current != null) {
	      if (e.compareTo(current.element) < 0) {
	        parent = current;
	        current = current.left;
	      }
	      else if (e.compareTo(current.element) > 0) {
	        parent = current;
	        current = current.right;
	      }
	      else
	        break; // Element is in the tree pointed at by current
	    }

	    if (current == null)
	      return false; // Element is not in the tree

	    // Case 1: current has no left children
	    if (current.left == null) {
	      // Connect the parent with the right child of the current node
	      if (parent == null) {
	        root = current.right;
	      }
	      else {
	        if (e.compareTo(parent.element) < 0)
	          parent.left = current.right;
	        else
	          parent.right = current.right;
	      }
	    }
	    else {
	      // Case 2: The current node has a left child
	      // Locate the rightmost node in the left subtree of
	      // the current node and also its parent
	      TreeNode<E> parentOfRightMost = current;
	      TreeNode<E> rightMost = current.left;

	      while (rightMost.right != null) {
	        parentOfRightMost = rightMost;
	        rightMost = rightMost.right; // Keep going to the right
	      }
	      //merge. Make the root of the right subtree of the node to be deleted 
	      //the right child of the right most node of the left subtree
	      rightMost.right= current.right;
	      //if the node to be deleted is not the root, make the root of the left subtree of the node to be deleted
	      //the right child of the parent to the node to be deleted.
	      if(current!=root)          
	        parent.right=current.left;
	      //otherwise make the root of the left subtree the root of the tree
	      else
	          root=current.left;
	    }

	    size--;
	    return true; 
	  }
	
	@Override /** Obtain an iterator. Use inorder. */
	public java.util.Iterator<E> iterator() {
		return new InorderIterator();
	}

	// Inner class InorderIterator
	private class InorderIterator implements java.util.Iterator<E> {
		// Store the elements in a list
		private java.util.ArrayList<E> list = new java.util.ArrayList<E>();
		private int current = 0; // Point to the current element in list

		public InorderIterator() {
			inorder(); // Traverse binary tree and store elements in list
		}

		/** Inorder traversal from the root */
		private void inorder() {
			inorder(root);
		}

		/** Inorder traversal from a subtree */
		private void inorder(TreeNode<E> root) {
			if (root == null)
				return;
			inorder(root.left);
			list.add(root.element);
			inorder(root.right);
		}

		@Override /** More elements for traversing? */
		public boolean hasNext() {
			if (current < list.size())
				return true;

			return false;
		}

		@Override /** Get the current element and move to the next */
		public E next() {
			return list.get(current++);
		}

		@Override /** Remove the current element */
		public void remove() {
			delete(list.get(current)); // Delete the current element
			list.clear(); // Clear the list
			inorder(); // Rebuild the list
		}
	}

	/** Remove all elements from the tree */
	public void clear() {
		root = null;
		size = 0;
	}

	public void breadthFirst() {
		TreeNode<E> node = root;
		GenericQueue<TreeNode<E>> queue = new GenericQueue<TreeNode<E>>();
		if (node != null) {
			queue.enqueue(node);
			while (!queue.isEmpty()) {
				node = queue.dequeue();
				System.out.println(node.element);
				if (node.left != null)
					queue.enqueue(node.left);
				if (node.right != null)
					queue.enqueue(node.right);
			} // end while
		} // end if
	}// end breadthFirst


	public int height() {
		return height(root);// Calculate the height from the root
	}

	  // recurssive height
	  public int height(TreeNode node){
	      if (node == null)// the base case
	        {
	            return 0;
	        }
	        else// the recursive curse
	        {
	            return 1 +
	            Math.max(height(node.left),// The height of the tree is the length from the root to the current node
	            height(node.right));// plus the maximum of the heights of its left and right sub trees
	        }
	     }
	  
	  public boolean recursiveSearch(E e, TreeNode<E> current) {
	      
	      return current != null && (current.element == e||
	                            recursiveSearch(e, current.left) ||
	                            recursiveSearch(e, current.right));
	  }
	  
	  
	public void iterativeInorder() {
		GenericStack<TreeNode<E>> stack = new GenericStack<TreeNode<E>>();
		TreeNode<E> node = root;

		while (node != null) {
			stack.push(node);
			node = node.left;
		}

		// Traverse the tree
		while (stack.size() > 0) {
			// Visit the top node
			node = stack.pop();
			System.out.print(node.element + " ");
			// Find the next node
			if (node.right != null) {
				node = node.right;
				// The next node to be visited is the leftmost
				while (node != null) {
					stack.push(node);
					node = node.left;
				}
			}
		}
	}// end iterativeInorder

	public void iterativePreorder() {
		TreeNode<E> node = root;

		if (node == null)
			return;

		GenericStack<TreeNode<E>> stack = new GenericStack<TreeNode<E>>();

		while (true) {
			while (node != null) {
				// process current Node
				System.out.print(node.element + " ");
				stack.push(node);
				node = node.left;
			}
			if (stack.isEmpty())
				break;
			node = stack.pop();
			node = node.right;
		}
	}// end iterativePreorder

	public void iterativePostorder() {
		if (root == null)
			return;

		GenericStack<TreeNode<E>> stack = new GenericStack<TreeNode<E>>();
		TreeNode<E> node = root;

		while (!stack.isEmpty() || node != null) {
			while (node != null) {
				if (node.right != null)
					stack.add(node.right);
				stack.add(node);
				node = node.left;
			}

			node = stack.pop();

			if (node.right != null && !stack.isEmpty() && node.right == stack.peek()) {
				TreeNode<E> nodeRight = stack.pop();
				stack.push(node);
				node = nodeRight;
			} else {
				System.out.print(node.element + " ");
				node = null;
			}
		}
	}// end iterativePostorder

	public TreeNode<E> delete(TreeNode<E> node) {
		TreeNode<E> current = root;

		if (node == null) {
			return node;

			// if this is not the node to delete;
			// recursively call this on the node's correct child
		} else if (node.element.compareTo(current.element) < 0) {
			node.left = delete(node.left);
			return node;
		} else if (node.element.compareTo(current.element) > 0) {
			node.right = delete(node.right);
			return node;
		}

		// if this is the node to delete:
		if (node.element.equals(node.element)) {
			// to delete it, we must return a subtree without it.

			if (node.left == null)
				return node.right;

			if (node.right == null)
				return node.left;

			// else node has 2 children, so delete by merging:
			// first, find its direct predecessor:
			TreeNode<E> temp = node.left;
			while (temp.right != null)
				temp = temp.right;

			// We have found the RM node, so now we merge the right subtree to
			// the RM node
			temp.right = node.right;
			// lastly, replace the node by its left subtree:
			return node.left;
		}

		return node;
	}

	public int getNumOfNonLeaves() {
		int total = 0;
		TreeNode<E> node = root;
		GenericQueue<TreeNode<E>> queue = new GenericQueue<TreeNode<E>>();
		if (node != null) {
			queue.enqueue(node);
			while (!queue.isEmpty()) {
				node = queue.dequeue();
				System.out.println(node.element);
				if (node.left != null && node.right != null)
					total++;

				if (node.left != null)
					queue.enqueue(node.left);
				if (node.right != null)
					queue.enqueue(node.right);
			} // end while
		} // end if

		return total;
	}

	public BST<E> mirrorOf(TreeNode<E> rootNode) {
		BST<E> mirrorTree = new BST<E>();
		TreeNode<E> node = root;
		GenericQueue<TreeNode<E>> queue = new GenericQueue<TreeNode<E>>();
		if (node != null) {
			queue.enqueue(node);
			while (!queue.isEmpty()) {
				node = queue.dequeue();
				if (node.right != null) {
					queue.enqueue(node.right);
					mirrorTree.mirrorInsert(node.right.element, mirrorTree);
				}
				if (node.left != null) {
					queue.enqueue(node.left);
					mirrorTree.mirrorInsert(node.left.element, mirrorTree);
				}

			} // end while
		} // end if

		mirrorTree.size++;

		return mirrorTree;
	}

	private void mirrorInsert(E e, BST<E> mirrorTree) {
		if (mirrorTree.root == null)
			mirrorTree.root = createNewNode(e); // Create a new root
		else {
			// Locate the parent node
			TreeNode<E> parent = null;
			TreeNode<E> current = mirrorTree.root;
			while (current != null)
				if (e.compareTo(current.element) < 0) {
					parent = current;
					current = current.right;
				} else if (e.compareTo(current.element) > 0) {
					parent = current;
					current = current.left;
				}

			// Create the new node and attach it to the parent node
			if (e.compareTo(parent.element) < 0)
				parent.right = createNewNode(e);
			else
				parent.left = createNewNode(e);
		}

		mirrorTree.size++;
	}
}