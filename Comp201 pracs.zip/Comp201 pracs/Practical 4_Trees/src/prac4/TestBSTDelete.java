package prac4;

public class TestBSTDelete {
	public static void main(String[] args) {
		BST<String> tree = new BST<String>();
		tree.insert("Nikiel");
		tree.insert("Riley");
		tree.insert("Shaelin");
		tree.insert("Rikesh");
		tree.insert("Hakeem");
		tree.insert("Harshil");
		tree.insert("Porn");
		printTree(tree);

		System.out.println("\nAfter delete Nabeela:");
		tree.deleteByMerging("Nabeela");
		printTree(tree);

		System.out.println("\nAfter delete Alex:");
		tree.deleteByMerging("Alex");
		printTree(tree);

		System.out.println("\nAfter delete Katie:");
		tree.deleteByMerging("Katie");
		printTree(tree);
	}

	public static void printTree(BST<String> tree) {
		// Traverse tree
		System.out.print("Inorder (sorted): ");
		tree.iterativeInorder();
		System.out.print("\nPostorder: ");
		tree.postorder();
		System.out.print("\nPreorder: ");
		tree.iterativePreorder();
		System.out.print("\nThe number of nodes is " + tree.getSize());
		System.out.println();
	}
}