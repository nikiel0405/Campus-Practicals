package prac3;

import prac2.MyLinkedList;

public class GenericQueue<E> extends MyLinkedList<E>{
	public GenericQueue(){
		
	}
	
	public GenericQueue(E[] objects){
		super(objects);
	}
	
	public void enqueue(E element){
		super.addLast(element);
	}
	
	public E dequeue(){
		return super.removeLast();
	}
	
	public int getSize(){
		return super.size;
	}
}
