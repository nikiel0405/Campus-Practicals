package prac3;

import prac2.MyArrayList;

public class GenericStack<E> extends MyArrayList<E> {
	
	public GenericStack(){
		
	}
	
	public GenericStack(E[] objects){
		super(objects);
	}
	
	public int getSize(){
		return super.size();
	}
	
	public E peek(){
		return (E) super.get(getSize()-1);
	}
	
	public E pop(){
		E element = peek();
		super.remove(element);
		return element;
	}
	
	public void push(E object){
		super.add(object);
	}
	
	public boolean isEmpty(){
		if (size != 0)
			return false;
		else
			return true;
	}
}//end class