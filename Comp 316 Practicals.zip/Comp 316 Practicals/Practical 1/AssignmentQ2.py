import re
import random

def modifier(inputs):
    x = inputs.upper()
    #pronoun conversion
    x = re.sub(r"\bME\b","YOU",x) 
    x = re.sub(r"\bMY\b","YOUR",x) 
    x = re.sub(r"\bI\b","YOU",x) 
    x = re.sub(r"\bWE\b","YOU",x) 

    x = re.sub(r"'M"," ARE",x) 
    x = re.sub(r"\bAM\b","ARE",x) 
    x = re.sub(r"\bMYSELF\b","YOURSELF", x)
    x = re.sub(r"\AWELL\b", "", x)
# change from first person to second person 
# could make it 2nd person to first person if you would like variety for 


    keys = [r"(?:\bALL\b)",r"(?:\bALWAYS\b)",r"(?:\bDEPRESSED\b)|(?:\bSAD\b)",r"(?:\bUNHAPPY\b)",r"(?:\bYOU\b(?: \bJUST\b)* \bNEED\b) ([A-Z 0-9_]*)",
            r"\A(?:\bYOUR\b (?:(?:\bMOTHER\b)|(?:\bFATHER\b)) )([^.]+)", r"(?:\bYOUR\b (\bMOTHER\b|\bFATHER\b)\.)"
    ]
    #key Words we are looking for in our text to generate replies
    replies = [
        ("IN WHAT WAY?","HOW SO?"),
        ("CAN YOU THINK OF A SPECIFIC EXAMPLE?","CAN YOU GIVE ME AN EXAMPLE OF SOMETHING THAT MAKES YOU FEEL THIS WAY?"),
        ("I AM SORRY TO HEAR THAT YOU ARE {}.","{} YOU SAY? I'M SORRY TO HEAR THAT."),
        ("DO YOU THINK THAT COMING HERE WILL HELP YOU NOT BE {}?","DO YOU BELIEVE THAT COMING HERE CAN HELP OVERCOME BEING {}?"),
        ("WHAT WOULD IT MEAN IF YOU COULD GET {}?","IF YOU WERE TO GET {},WHAT DO YOU THINK WILL HAPPEN?"),
        ("WHO ELSE {}?","IS THERE ANYBODY ELSE WHO {}?"),
        ("TELL ME MORE ABOUT YOUR FAMILY.","WHAT ELSE CAN YOU TELL ME ABOUT YOUR FAMILY?")
    ]
    # different replies which can be automatically generated

    # use of lists makes it easier to map replies to a specific keyword while at the same time allowing for multiple responses to be generated for a specific keyword


    for i in range(0, len(keys)):
        pattern = keys[i]
        match = re.findall(pattern,x)

        if match :
            match = random.choice(match)


            x = random.choice(replies[i]).format(match)
            break
    return x 

'''Main method to carry out the dialogue'''
inputs=""
while(inputs != "Bye"):
    inputs = input()
    output = modifier(inputs)
    print(output)