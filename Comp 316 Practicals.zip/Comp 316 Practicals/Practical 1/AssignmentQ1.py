import re
laptops = open("laptops.txt",'r')
lines  = laptops.readlines()

print("Prices :")
x = re.findall( r"([R$](?:[0-9])+(?:[,.])*(?:[0-9]+(?:[,.])*)(?:[0-9])*)",str(lines))
for y in x:
    print(y)
print("-----------------------------------------")

print("Processors :")
x = set(re.findall(r"(Intel (?:C|P)\w+ (?:i|N)[0-9]+(?:-*[0-9]*[A-Z]*))",str(lines)))
for y in x:
    print(y)
print("-----------------------------------------")

print("Brands :")
for line in set(lines):
    x = re.findall(r"(?:^by (\w+)$)", line)
    for y in x:
        print(y)
print("-----------------------------------------")

print("How many new :")
x=re.findall(r"[0-9]+ new",str(lines))
for y in x:
    print(re.sub(" new","",y))
print("-----------------------------------------")

print("Customer reviews :")
x=re.findall(r"[0-9]+ customer reviews",str(lines))
for y in x:
    print(re.sub(" customer reviews","",y))
print("-----------------------------------------")