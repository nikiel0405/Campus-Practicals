/**
 * 
 */
package stocks;

/**
 * @author anban
 *
 */
public class Stock {
	/** the stock symnol*/
	private String symbol;
	
	/** total cost of the stock*/
	private double totalCost;
	
	/** current price of the stock */
	private double currentPrice;

	public Stock(double totalCost, double currentPrice) {
		super();
		this.totalCost = totalCost;
		this.currentPrice = currentPrice;
	}

	/**
	 * @return the currentPrice
	 */
	public double getCurrentPrice() {
		return currentPrice;
	}

	/**
	 * @param currentPrice the currentPrice to set
	 */
	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	/**
	 * @return the totalCost
	 */
	public double getTotalCost() {
		return totalCost;
	}
	/**
	 * Adds a cost to this stock.
	 * @param cost
	 */
	public void addCost(double cost) {
		totalCost += cost;
	}
	
}
