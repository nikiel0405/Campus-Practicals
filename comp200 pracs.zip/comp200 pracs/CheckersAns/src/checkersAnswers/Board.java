package checkersAnswers;



import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class Board extends JPanel implements MouseListener {
		private Square[][] squares = new Square[8][8];
	
		private int turn = Square.WHITE;
		
		private Square firstSelected = null;
		private Square secondSelected = null;

		public Board(){
				
				//setLayout(new GridLayout(8,8));
				
				boolean isWhite = true;   
				
			    for (int row = 0; row < 8; row++) {
			      for (int col = 0; col < 8; col++) {
			       
			        if (isWhite) {
			          squares[row][col] = new Square(row,col,Square.WHITE);
			          isWhite = false;
			        }
			        else {
			          squares[row][col] = new Square(row,col,Square.BLACK);
			          if(row < 3){
			        	  squares[row][col].addPiece(new Piece(Square.BLACK));
			          }
			          if(row > 4){
			        	  squares[row][col].addPiece(new Piece(Square.WHITE));
			          }
			          isWhite = true;
			        }
			        //add(squares[i][j]); 
			      }
			      if (row % 2 == 0)
				        isWhite = false; 
				      else
				        isWhite = true;
			     
			    } 
				this.addMouseListener(this);
			    
				
				
				repaint();
				for(int i = 0; i<50; i++) {
					System.out.println((int) (Math.random() * 6)+1) ;
				}
		}
	
	
		public void paintComponent(Graphics g){
			super.paintComponent(g);
			for(int i = 0; i < 8; i++){
			    	for(int j = 0; j < 8; j++){
			    		squares[i][j].draw(g);
			    	}
			    }
		}


		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			Square s = squares[e.getY()/Square.SIZE][e.getX()/Square.SIZE];
				if (this.firstSelected == null) {
					if(s.getPiece()==null){
						System.out.println("no piece on square");
					}
					else{
						if(s.getPiece().getColor()==turn){
							firstSelected = s;
						}
						else{
							JOptionPane.showMessageDialog(null, "NOT YOUR TURN");
						}

					}
				}


				else {
						secondSelected = s;
						if (checkvalid() == true) {
							move();
							turn = (turn+1)%2;
						}
						else{
							JOptionPane.showMessageDialog(null, "INVALID MOVE");
							firstSelected = null;
							secondSelected = null;
							if (secondSelected.Gety() == 7 && firstSelected.getPiece().getColor() == Square.BLACK){
								firstSelected.getPiece().makeKing();
							}

						}
					}

		}



		public boolean checkvalid(){
			boolean t;
			int o1 = firstSelected.Getx() -secondSelected.Getx();// first col - second col
			int i1 = firstSelected.Gety() - secondSelected.Gety();// first row - second row
			int o2 = secondSelected.Getx() - firstSelected.Getx();// second col - first col
			int i2 = secondSelected.Gety() - firstSelected.Gety();//second row - first row

			if ((o1== 60 && i1==60 )&&  ((firstSelected.getPiece().getColor() == Square.WHITE) ||(firstSelected.getPiece().isKing()))){
				t = true;
			}
			else if((o2==60 && i1==60 )&& ((firstSelected.getPiece().getColor() ==Square.WHITE)||(firstSelected.getPiece().isKing()))){
				t = true;
			}
			else if((o1==60 && i2==60) && ((firstSelected.getPiece().getColor() == Square.BLACK )||(firstSelected.getPiece().isKing()))){
				t = true;
			}
			else if ((o2==60 && i2==60 )&& ((firstSelected.getPiece().getColor() ==Square.BLACK )||(firstSelected.getPiece().isKing()))){
				t = true;
			}
			else if (jumped()){
				t = true;
				turn = (turn +1)%2;
			}
			else{
				t = false;
			}
			return t;
		}

		public boolean jumped(){
			boolean t;


			int midx = (firstSelected.Getx() +secondSelected.Getx())/2;
			int midy = (firstSelected.Gety() + secondSelected.Gety())/2;
			Square s =  squares[midy/60][midx/60];

			if ((secondSelected.getPiece() == null)  && (firstSelected.getPiece() != s.getPiece())){
				s.removePiece();
				t = true;
			}
			else{
				t = false;
			}
			return t;
		}



		public void move(){
				if (firstSelected.getPiece() != null) {
					Piece p = firstSelected.getPiece();
					firstSelected.removePiece();
					secondSelected.addPiece(p);
					firstSelected = null;
					secondSelected = null;
					repaint();
				}
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}


		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}


		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}


		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	
	
	
}
