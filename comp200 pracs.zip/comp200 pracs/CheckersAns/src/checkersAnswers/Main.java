package checkersAnswers;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        JFrame checkers = new JFrame();
        checkers.setSize(400, 400);
        checkers.setLocationRelativeTo(null);
        checkers.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        checkers.setTitle("CheckerBoard");
        checkers.add(new Board());
        checkers.setVisible(true);// write your code here
    }
}
