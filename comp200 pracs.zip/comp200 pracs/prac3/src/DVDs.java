public class DVDs extends item {

    private String director;
    private int runningTime;

    public DVDs(String n, String c, Double v,String dir, int Run) {
        super(n, c, v);
        this.director = dir;
        this.runningTime = Run;
    }

    public DVDs() {
        this.director = "";
        this.runningTime =  0;
    }

    public String getDirector() {
        return director;
    }

    public int getRunningTime() {
        return runningTime;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public void setRunningTime(int runningTime) {
        this.runningTime = runningTime;
    }

    @Override
    public String toString() {
        return (super.toString()+"director = "+getDirector()+"running time = "+getRunningTime());
    }

    @Override
    public void depreciate() {
        setValue((getValue())- (getValue()*0.15));
    }
}
