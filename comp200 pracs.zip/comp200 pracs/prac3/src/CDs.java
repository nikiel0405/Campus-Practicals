public class CDs extends item {

    private String artist;
    private int playingTime;

    public CDs(String n, String c, Double v, String art, int play) {
        super(n, c, v);
        this.artist  =art;
        this.playingTime = play;

    }

    public CDs() {

        this.artist = "";
        this.playingTime = 0;
    }

    public String getArtist() {
        return this.artist;
    }

    public int getPlayingTime() {
        return this.playingTime;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public void setPlayingTime(int playingTime) {
        this.playingTime = playingTime;
    }

    @Override
    public String toString() {
        return (super.toString()+"Artist = "+getArtist()+"Playing time = "+getPlayingTime());
    }

    @Override
    public void depreciate() {
        setValue( (getValue()) - ( getValue()*0.1 ));
    }
}
