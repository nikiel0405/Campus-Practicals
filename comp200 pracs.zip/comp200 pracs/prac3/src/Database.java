public class Database {

    public item[] db;

    public Database(int num) {
        db = new item[num];
    }

    public void addItem(item c){
        int pos = 0;
        for(int i = 0; i<db.length;i++){

            if(db[i] == null){
                pos= i;
                break;
            }

        }
        db[pos] = c;
    }

    public void removeItem(item c){
        int pos = 0;
        for(int i = 0; i<db.length;i++){

            if(db[i] == c){
                pos= i;
                break;
            }

        }
        db[pos] = null;
    }

    public void print(){
        for(int i = 0; i<db.length;i++){
            System.out.println(db[i].toString());
        }
    }
    public void depItem(){
        for(int i = 0; i<db.length;i++){
            db[i].depreciate();
        }
    }
}
