public class item {

    private String name;
    private String comment;
    private double value;

    public item(String n, String c, Double v){
        this.name = n;
        this.comment = c;
        this.value = v;
    }
    public item(){
        this.value = 0;
        this.comment = "";
        this.name = "";
    }


    public String getName(){
        return this.name;
    }
    public String getComment(){
        return this.comment;
    }
    public Double getValue(){
        return this.value;
    }
    public void setName(String name){
        this.name = name;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public void depreciate(){
        this.value -= (this.value * 0.05);
    }

    public String toString() {

        return ("name = "+getName()+" comment = "+getComment()+" value = "+getValue());
    }
}
