package questionOne;

public class MotorisedVehicle extends Vehicle {
    private int engineCapacity;
    public MotorisedVehicle(int numWheels, int engineCapacity){
        super(numWheels);
        this.engineCapacity = engineCapacity;
    }
    public int getEngineCapacity(){
        return engineCapacity;
    }

}
