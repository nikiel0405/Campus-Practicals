package questionOne;

public class Vehicle {
    private int numberOfWheels;
    public Vehicle(int numWheels){
        numberOfWheels = numWheels;
    }
    public int getNumberOfWheels(){
        return numberOfWheels;
    }



}