package questionOne;

import java.util.ArrayList;

public class TestVehicles{

    public static void main(String[] args) {
	// write your code here
        Object o = new MotorisedVehicle(4,2000);
        System.out.println();




    }
}
