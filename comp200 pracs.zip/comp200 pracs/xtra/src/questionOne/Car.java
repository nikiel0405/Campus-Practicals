package questionOne;

public class Car extends MotorisedVehicle {

    public int Doors = 0;
    public Car(int numWheels, int engineCapacity, int door){
        super(numWheels, engineCapacity);
        Doors = door;
    }

}
