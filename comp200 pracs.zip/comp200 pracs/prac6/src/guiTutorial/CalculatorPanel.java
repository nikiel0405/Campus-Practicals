package guiTutorial;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorPanel extends JPanel {

    JTextField xInput, yInput;
    JTextField answer;

    public CalculatorPanel() {
        //JPanel Calc = new JPanel();
        setLayout(new GridLayout(4, 1, 2, 2));
        xInput = new JTextField("0");
        JLabel xLable = new JLabel("x = 0   ");
        JPanel xPanel = new JPanel(new BorderLayout());
        xPanel.add(xInput, BorderLayout.CENTER);
        xPanel.add(xLable, BorderLayout.WEST);

        ActionListener command = new CommandAction() ;

        yInput = new JTextField("0");
        JLabel yLable = new JLabel("y = 0   ");
        JPanel yPanel = new JPanel(new BorderLayout());
        yPanel.add(yInput, BorderLayout.CENTER);
        yPanel.add(yLable, BorderLayout.WEST);

        answer = new JTextField("0");
        JLabel answerLable = new JLabel("answer = 0 ");
        JPanel answerPanel = new JPanel(new BorderLayout());
        answerPanel.add(answer, BorderLayout.CENTER);
        answerPanel.add(answerLable, BorderLayout.WEST);

        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(new GridLayout(1, 4));

        JButton plus = new JButton("+");
        JButton minus = new JButton("-");
        JButton multi = new JButton("*");
        JButton div = new JButton("/");
        plus.addActionListener(command);
        minus.addActionListener(command);
        multi.addActionListener(command);
        div.addActionListener(command);
        btnPanel.add(plus);
        btnPanel.add(minus);
        btnPanel.add(multi);
        btnPanel.add(div);

        add(answerPanel);
        add(xPanel);
        add(yPanel);
        add(btnPanel);
        setVisible(true);
        answer.setEditable(false);
    }

    public class CommandAction implements ActionListener {
        @Override

        public void actionPerformed(ActionEvent evt) {
            double x, y;

            try {
                String xStr = xInput.getText();
                x = Double.parseDouble(xStr);
            } catch (NumberFormatException e) {
                // The string xStr is not a
                // l e g a l number .
                answer.setText(" Illegal data for x . ");
                return;
            }

            try {
                String yStr = yInput.getText();
                y = Double.parseDouble(yStr);
            } catch (NumberFormatException e) {
                // The string xStr is not a
                // l e g a l number .
                answer.setText(" Illegal data for y . ");
                return;
            }

            String op = evt.getActionCommand();

            if (op.equals("+")) {
                answer.setText(" x + y = "
                        + (x + y));
            }
            else if (op.equals("-")) {
                answer.setText(" x - y = "
                        + (x - y));
            }
            else if (op.equals("*")) {
                answer.setText(" x * y = "
                        + (x * y));
            }
            else if (op.equals("/")) {
                if (y == 0) {
                    answer.setText("Can’ t divide by zero ");
                }
                    else{
                        answer.setText(" x / y = "
                                + (x / y));
                    }
                }
            }

        }
}





