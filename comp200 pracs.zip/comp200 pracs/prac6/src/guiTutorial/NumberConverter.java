package guiTutorial;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NumberConverter extends JPanel {

    JTextField xInput, yInput;
    JTextField answer;

    public NumberConverter() {
        //JPanel Calc = new JPanel();
        setLayout(new GridLayout(4, 1, 2, 2));


        xInput = new JTextField("0");
        JLabel xLable = new JLabel(" Number  ");
        JPanel xPanel = new JPanel(new BorderLayout());
        xPanel.add(xInput, BorderLayout.CENTER);
        xPanel.add(xLable, BorderLayout.WEST);

        ActionListener command = new CommandAction() ;

        yInput = new JTextField("0");
        JLabel yLable = new JLabel("radix / base ");
        JPanel yPanel = new JPanel(new BorderLayout());
        yPanel.add(yInput, BorderLayout.CENTER);
        yPanel.add(yLable, BorderLayout.WEST);


        answer = new JTextField("0");
        JLabel answerLable = new JLabel("answer = 0 ");
        JPanel answerPanel = new JPanel(new BorderLayout());
        answerPanel.add(answer, BorderLayout.CENTER);
        answerPanel.add(answerLable, BorderLayout.WEST);

        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(new GridLayout(1, 4));

        JButton bin = new JButton("BIN");
        JButton oct = new JButton("OCT");
        JButton hex = new JButton("HEX");
        JButton dec = new JButton("DEC");
        bin.addActionListener(command);
        oct.addActionListener(command);
        hex.addActionListener(command);
        dec.addActionListener(command);

        btnPanel.add(bin);
        btnPanel.add(oct);
        btnPanel.add(hex);
        btnPanel.add(dec);

        add(answerPanel);
        add(xPanel);
        add(yPanel);
        add(btnPanel);
        setVisible(true);
        answer.setEditable(false);
    }

    public class CommandAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent evt) {
            int x, y;

            //String x = xInput.getText();
            try {
                y = Integer.parseInt(yInput.getText());
                x = Integer.parseInt(xInput.getText(), y);



            } catch (NumberFormatException e) {
                // The string xStr is not a
                // l e g a l number .
                answer.setText(" Illegal data for x . ");
                return;
            }




            String op = evt.getActionCommand();

            if (op.equals("BIN")) {

                int rad = Integer.parseInt(yInput.getText());
                answer.setText("" +Integer.toBinaryString(Integer.parseInt(xInput.getText(), rad)));
            }
            else if (op.equals("OCT")) {
                int rad = Integer.parseInt(yInput.getText());
                answer.setText("" +Integer.toOctalString(Integer.parseInt(xInput.getText(), rad)));



            }
            else if (op.equals("HEX")) {
                int rad = Integer.parseInt(yInput.getText());
                answer.setText("" +Integer.toHexString(Integer.parseInt(xInput.getText(), rad)));
            }
            else if (op.equals("DEC")) {
                int rad = Integer.parseInt(yInput.getText());
                answer.setText("" + Integer.parseInt(xInput.getText() , rad));



            }
        }

    }
}





