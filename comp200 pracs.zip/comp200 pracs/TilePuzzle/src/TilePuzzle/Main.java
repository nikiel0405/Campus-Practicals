package TilePuzzle;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        JFrame puzzle = new JFrame();
        puzzle.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        puzzle.setLocationRelativeTo(null);
        puzzle.setResizable(true);
        puzzle.add(new Board());
        puzzle.setVisible(true);
        puzzle.setTitle("Puzzle");
        puzzle.setSize(600,600);
        // moved puzzle.add(new Board()) to before puzzle.setVisible(true);
	// write your code here
    }
}
