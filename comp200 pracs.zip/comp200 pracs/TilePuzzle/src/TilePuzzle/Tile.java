package TilePuzzle;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Tile extends JPanel {
    private int tileNumber;
    private boolean isBlank;
    private Image image;
    public static final int SIZE = 200;

    public Tile(int tileNumber, boolean isBlank){
        this.tileNumber = tileNumber;
        this.isBlank = isBlank;
        if (isBlank == false) {
            try {
                image = ImageIO.read(new File("Images/Tile0" + tileNumber + ".gif"));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "The image file cannot be found", "error:", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else{
            image = null;
        }
        this.setVisible(true);
        this.setSize(200,200);
    }

    public void draw(Graphics g, int row, int col){
        if (image != null) {
            g.drawImage(image, col * 200, row * 200, 200, 200, null);
        }

        else
        {
            g.setColor(Color.GRAY);
            g.fillRect(col * 200, row * 200, 200, 200);
            //g.fillRect(row * 200, col * 200, 200, 200);
        }
    }

}
