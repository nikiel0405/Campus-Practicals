package TilePuzzle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Board extends JPanel {

    private Tile[][] Board = new Tile[3][3];
    private int blankRow, rowSelected;
    private int blankCol, colSelected;
    private Tile selected = null;

    /**selected, rowselected, colselected unecessary:
     * only one tile is clicked per attempted move
     * the second tile is always the blank tile :Board[blankRow][blankCol]
     **/
    private int tileCount;

    public Board() {
        this.setVisible(true);
        tileCount = 0;
        for (int row = 0; row < Board.length; row++) {
            for (int col = 0; col < Board[row].length; col++) {
                tileCount += 1;
                if (tileCount < 9) {
                    Board[row][col] = new Tile(tileCount, false);
                } else {
                    Board[row][col] = new Tile(tileCount, true);
                    this.blankRow = row;
                    this.blankCol = col;
                    System.out.println(blankRow+","+blankCol);
                }
            }
        }
        this.addMouseListener(new ClickListener());
        repaint();
    }

    public boolean checkComplete() {
        return true;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (int row = 0; row < Board.length; row++) {
            for (int col = 0; col < Board[row].length; col++) {
                Board[row][col].draw(g, row, col);
                //repaint();
                //not necessary to call repaint within paintComponent.
            }
        }
    }

    public void shuffle() {

    }

    public boolean adjacent(int row, int col) {
        //new adjacent definition
        if(Math.pow((row - blankRow),2)  +   Math.pow((col - blankCol),2) == 1){
            return true;
        }
        else{
            return false;
        }

        //old adjacent definition
       /** if ((row == blankRow) && (col == blankCol)) {
            return true;
        } else {
            return false;
        }**/
    }

    public void move(int row, int col) {
        //new move definition
        Tile swap = Board[row][col];
        Board[row][col] = Board[blankRow][blankCol];
        Board[blankRow][blankCol] = swap;
        blankRow = row;
        blankCol = col;

        /**
        if (adjacent(row, col)) {
            Tile swap = Board[row][col];
            Board[row][col] = selected;
            Board[rowSelected][colSelected] = swap;
        }
        selected = null;
        **/

    }

    public class ClickListener implements MouseListener {

        public void mouseClicked(MouseEvent evt) {
            //new mouseClicked definition
            int row = evt.getY() / Tile.SIZE;
            int col = evt.getX() / Tile.SIZE;

            if(adjacent(row,col)){
                move(row ,col);
                repaint();
            }

            //old mouseClicked definition
            /**
            int row = evt.getY() / Tile.SIZE;
            int col = evt.getX() / Tile.SIZE;
            if (selected == null) {
                rowSelected = row;
                colSelected = col;
                Tile t = Board[row][col];
                selected = t;
            } else {
                move(row, col);
            }**/
        }

        public void mouseEntered(MouseEvent arg0){}
        public void mouseExited(MouseEvent arg0){}
        public void mousePressed(MouseEvent arg0){}
        public void mouseReleased(MouseEvent arg0){}

    }

}
