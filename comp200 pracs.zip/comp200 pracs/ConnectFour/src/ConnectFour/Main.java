package ConnectFour;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        // write your code here
        JFrame myframe = new JFrame();
        myframe.setDefaultCloseOperation(3);
        myframe.setTitle("Connect Four");
        myframe.setSize(715, 635);
        myframe.setVisible(true);
        myframe.add(new Board());


    }
}
