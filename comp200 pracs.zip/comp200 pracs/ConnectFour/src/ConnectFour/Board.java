package ConnectFour;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import static ConnectFour.Disc.BLACK;
import static ConnectFour.Disc.RED;
import static ConnectFour.Disc.SIZE;

public class Board extends JPanel implements MouseListener {

    private Square[][] board;
    private int turn;

    public Board(){
        turn = BLACK;
        board = new Square[7][6];
        for(int x = 0; x < 7; x++){
            for(int y = 0; y < 6; y++){
                board[x][y] = new Square();
            }
        }

        addMouseListener(this);


    }





    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        for(int x = 0; x < 7; x++){
            for(int y = 0; y < 6; y++){
                board[x][y].draw(g,x,y);
            }
        }
    }

    public void startFresh(){
        for(int x = 0; x < 7; x++){
            for(int y = 0; y < 6; y++){
                board[x][y].removeDisc();
            }
        }
        repaint();
    }


    public void checkWin(int color){
        int oppositeColor = color*-1;
        int pieceCount = 0;

        for(int x = 0; x < 7; x++){
            for(int y = 0; y < 6; y++){
                if(board[x][y].getDisc() != null && board[x][y].getDisc().getColor() == color){
                    pieceCount++;
                    if( (y+1 != 6) && ( (board[x][y+1].getDisc() == null) || (board[x][y+1].getDisc().getColor() == oppositeColor) ) && (pieceCount < 4) ){
                        pieceCount = 0;
                    }
                }
            }

            if(pieceCount >= 4){
                if(color == BLACK){
                    JOptionPane.showMessageDialog(null,"BBC wins");
                    startFresh();
                    break;
                }else{
                    JOptionPane.showMessageDialog(null,"RBC wins");
                    startFresh();
                    break;
                }
            }
            pieceCount = 0;

        }

        pieceCount = 0;

        for(int y = 0; y < 6; y++){
            for(int x = 0; x < 7; x++){
                if(board[x][y].getDisc() != null && board[x][y].getDisc().getColor() == color){
                    pieceCount++;
                    if( (x+1 != 7) && ( (board[x+1][y].getDisc() == null) || (board[x+1][y].getDisc().getColor() == oppositeColor) ) && (pieceCount < 4) ){
                        pieceCount = 0;
                    }
                }
            }
            if(pieceCount >= 4){
                if(color == BLACK){
                    JOptionPane.showMessageDialog(null,"BBC wins");
                    startFresh();
                    break;
                }else{
                    JOptionPane.showMessageDialog(null,"RBC wins");
                    startFresh();
                    break;
                }
            }
            pieceCount = 0;
        }


    }



    public void checkDraw(){
        int countDisc = 0;
        for(int x = 0; x < 7; x++){
            if(board[x][0].getDisc() != null){
                countDisc++;
            }
        }
        if(countDisc == 7){
            JOptionPane.showMessageDialog(null,"Draw");
            startFresh();
        }
    }



    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX()/SIZE;

        for(int y = 5; y >= 0; y--){
            if(board[x][y].getDisc()==null){
                board[x][y].addDisc(new Disc(turn));
                turn *= -1;
                break;

            }
        }


        repaint();
        checkDraw();
        checkWin(BLACK);
        checkWin(RED);

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
