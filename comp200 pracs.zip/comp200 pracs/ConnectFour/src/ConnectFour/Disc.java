package ConnectFour;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Disc {

    public static final int SIZE = 100;
    public static final int BLACK = -1;
    public final static int RED = 1;
    private int color;
    private Image image;

    public Disc(int color){
        this.color = color;
        try{
            if(this.color == BLACK){
                image = ImageIO.read(new File("images\\black.gif"));
            }else {
                image = ImageIO.read(new File("images\\red.gif"));
            }
        }catch(IOException e){
            System.out.println("Puusssss");
        }
    }


    public void draw(Graphics g, int x, int y){
        g.drawImage(image,x*SIZE,y*SIZE,SIZE,SIZE,null);
    }


    public int getColor(){
        return this.color;
    }


}
