package ConnectFour;
import java.awt.*;

import static ConnectFour.Disc.SIZE;



public class Square {

    private Disc d;

    public void addDisc(Disc disc){
        this.d = disc;
    }

    public void removeDisc(){
        this.d = null;
    }

    public void draw(Graphics g, int x, int y){
        g.drawRect(x*SIZE,y*SIZE,SIZE,SIZE);
        if(this.d != null){
            d.draw(g,x,y);
        }
    }

    public Disc getDisc(){
        return this.d;
    }






}
