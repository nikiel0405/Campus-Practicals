package cardGames;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Deck d = new Deck();

        Hand player = new Hand();
        Hand dealer = new Hand();
        player.addCard(d.dealCard());

        System.out.println();


        System.out.println(d.dealCard());
    }
}
