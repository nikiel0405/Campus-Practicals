package cardGames; /**
 * 
 */

/**
 * @author anban
 *
 */
public class Hand {
	private Card[] hand;
	
	//creates a hand to hold 10 cards
	public Hand() {
		hand = new Card[10];

	}
	
	//create a hand to hold num cards
	public Hand(int num) {
		hand = new Card[num];
	}
	
	//add a card to this hand
	public void addCard(Card c) {

		int pos = 0;
		for(int j = 0; j < hand.length;j++ ){

			if (hand[j] == null){
				pos = j;

			}

		}
		hand[pos] = c;

		
	}

	//remove the card at index i from this hand
	public void removeCard(int i) {

		hand[i] = null;

	}
	
	//return the value of the cards in this hand
	public int value() {
		int val = 0;
		for(int i = 0 ; i<hand.length; i++) {
			if (hand[i] != null) {

				if ((hand[i].getValue() == 1) && ((val + 11) <= 21)) {
					val += 11;
				}
				else if ((hand[i].getValue() == 11) || (hand[i].getValue() == 12) || (hand[i].getValue() == 13)) {
					val += 10;
				}
				else {
					val += hand[i].getValue();
				}

			}
			else{
				val +=0;
			}
		}
		return val;
	}
	
}
