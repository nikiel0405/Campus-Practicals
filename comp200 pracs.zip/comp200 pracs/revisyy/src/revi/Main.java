package revi;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        JFrame board = new JFrame();
        board.setSize(600, 600);
        board.setLocationRelativeTo(null);
        board.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        board.setTitle("BlackHoles and portals");
        board.add(new Board());
        board.setVisible(true);
    }
}
