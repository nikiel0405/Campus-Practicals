package revi;

import java.awt.*;

public class Dice {

    private int value;

    public Dice(){
        value = (int) (Math.random() *6)+1 ;
    }

    public  int getValue(){
        return value;
    }

    public int roll(){
        value = (int) (Math.random() *6)+1;
        return getValue();
    }

    public void draw(Graphics g, int x, int y, int w, int h ){
        g.fillRect(x, y, w, h);
    }
}
