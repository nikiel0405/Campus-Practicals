package revi;

import java.awt.*;

public class Square {

    public static final int SIZE = 100;
    public static int counter = 1;
    public int val;

    public void draw(Graphics g, int x, int y, String s){
        g.setColor(Color.BLACK);
        g.drawRect(x*SIZE, y*SIZE, SIZE, SIZE);
        val = Integer.parseInt(s);
        g.drawString(s, x*SIZE+32, y*SIZE+50);

    }

    public int Getval(){
        return val;
    }


}
