package revi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayDeque;
import java.util.ArrayList;

public class Board extends JPanel implements MouseListener {

    private Square[][] square;
    private  Counter[] counters;
    private ArrayList<Chute> chutes;
    private  int turn;
    private  Dice dice;



    public Board(){
        square = new Square[10][10];
        for(int i = 0; i<10; i++){
            for (int j = 0; j <10 ; j++){
                square[i][j] = new Square();
            }

        }


    }
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        int a = 100;
        String val;
        for(int i = 0; i<10; i++){
            for(int j = 0; j<10; j++){
                val = Integer.toString(a);
                square[j][i].draw(g, j, i, val);
                a--;

            }

        }
    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }


}
