package cardGames;

import javax.swing.*;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
	// write your code here
        JFrame myFrame = new JFrame();
        myFrame.setSize(400,600);
        myFrame.setDefaultCloseOperation(3);
        myFrame.setVisible(true);
        myFrame.add(new UI());
        BlackJackHand dealersHand = new BlackJackHand();
        BlackJackHand playersHand = new BlackJackHand();





    }
}
