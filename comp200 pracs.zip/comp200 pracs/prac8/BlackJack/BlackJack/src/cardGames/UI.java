package cardGames;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class UI extends JPanel {

    private JPanel TableD = new JPanel();
    private JPanel TableP = new JPanel();


    public UI() throws IOException {
            JPanel btnPanel = new JPanel();
            btnPanel.setLayout(new FlowLayout());
            JButton jbtHit = new JButton("Hit!");
            JButton jbtStand = new JButton("Stand!");
            JButton jbtNewGame = new JButton("New Game");
            btnPanel.add(jbtHit);
            btnPanel.add(jbtStand);
            btnPanel.add(jbtNewGame);
            TableD.setBackground(Color.GREEN);
            TableP.setBackground(Color.GREEN);
            Dimension d = new Dimension(400,250);
            TableD.setLayout(new BorderLayout());
            TableD.add(new cardUI(20,20));
            TableD.add(new JLabel("Dealer:"),BorderLayout.NORTH);
            TableD.setPreferredSize(d);
            TableP.setLayout(new BorderLayout());
            TableP.add(new JLabel("Your Hand: "),BorderLayout.NORTH);
            TableP.add(new JLabel("You have "+" Hit or Stand?"),BorderLayout.SOUTH);
            this.setLayout(new BorderLayout());
            this.add(TableD, BorderLayout.NORTH);
            this.add(TableP, BorderLayout.CENTER);
            this.add(btnPanel, BorderLayout.SOUTH);
    }
}
