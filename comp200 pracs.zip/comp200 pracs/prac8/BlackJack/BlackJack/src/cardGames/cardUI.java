package cardGames;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class cardUI extends JPanel {

    public int cardx;
    public int cardy;
    public String simage = "";

    public cardUI(int x, int y)  throws IOException{
        cardx = x;
        cardy = y;
        this.setBackground(Color.GREEN);
        Card z = new Card(2,5);
        int suit = z.getSuit();
        int value = z.getValue();
        String ssuit = "";


        if(suit == 0){
            ssuit = "h";
        }else if(suit == 1){
            ssuit = "c";
        }else if(suit == 2){
            ssuit = "s";
        }else if(suit == 3){
            ssuit = "d";
        }

        simage = ssuit + Integer.toString(value);

    }




    @Override
    protected void paintComponent(Graphics g)  {
        super.paintComponent(g);
        Image myImage = null;
        try {
            myImage = ImageIO.read(new File("cardImages\\"+simage+".gif"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        g.drawImage(myImage,cardx,cardy,70,100,null);

    }





}
