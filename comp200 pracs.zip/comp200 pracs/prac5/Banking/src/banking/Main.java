package banking;


import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        // write your code here

        ArrayList<BankAccount> acc = new ArrayList<BankAccount>();
        Scanner trans = new Scanner(new File("transactions.txt"));
        Scanner acount = new Scanner(new File("accounts.txt"));
        acount.nextLine();

        while (acount.hasNext()) {
            int accno = acount.nextInt();
            String acctype = acount.next();
            String accholder = acount.next() + " " + acount.next();
            double opbal = acount.nextDouble();
            if (acctype.equals("Current")) {
                BankAccount c = new CurrentAccount(accno, accholder, opbal);
                acc.add(acc.size(), c);
            } else if (acctype.equals("Savings")) {
                BankAccount c = new SavingsAccount(accno, accholder, opbal);
                acc.add(acc.size(), c);

            }
            else{
                System.out.println("invalid account type");
            }

        }//end while



        trans.nextLine();
        while (trans.hasNext()) {
            int day = trans.nextInt();

            int month = trans.nextInt();

            int year = trans.nextInt();

            int acno = trans.nextInt();

            String type = (trans.next()).trim();
            System.out.println(type);
            double amm = trans.nextDouble();

            int toacc = 0000;
            int transtype = -1;


           switch(type){
                case "withdraw" :  transtype = Transaction.WITHDRAW;
                case "deposit" : transtype = Transaction.DEPOSIT;
                case "transfer" : transtype = Transaction.TRANSFER;
            }

            if (type.equals("transfer")) {

                toacc = trans.nextInt();
            }
            else{
                trans.nextLine();
            }

            int b = 0;
            int c = 0;

            for (int i = 0; i < acc.size(); i++) {

                    if (acno == (acc.get(i)).getAccountNumber() ){
                        b = i;

                }



            }//ends for loop

            for (int j = 0; j < acc.size(); j++) {
                if (toacc == (acc.get(j)).getAccountNumber()) {
                    c = j;
                }

            }//ends for

            Transaction t = new Transaction(day, month, year, transtype, acc.get(c), amm);
            (acc.get(b)).processTransaction(t);




        }

        for (int k = 0; k<acc.size(); k++){
            acc.get(k);
            acc.get(k).deductFees();
            (acc.get(k)).printStatement();
        }
    }

}
