package banking;

public class SavingsAccount extends BankAccount{

    protected final double interest = 1.5/100;

    public SavingsAccount(int accountNumber, String accountHolder, double openingBalance) {
        super(accountNumber, accountHolder, openingBalance);

    }




    public void deductFees(){

        this.withdraw(50);
        this.transactionCount = 0;

    }

    public boolean withdraw (double amount){

        if(this.getBalance() <500 ){
            System.out.println("Insufficient funds");
            return false;
        }
        else {
            this.balance -=amount;
            return true;
        }
    }
    public void addInterest(){
        deposit(this.balance * interest);
    }


}
