package banking;

public class CurrentAccount extends BankAccount {

    public CurrentAccount(int accountNumber, String accountHolder, double openingBalance) {
        super(accountNumber, accountHolder, openingBalance);
    }


    public boolean withdraw(double amount) {
        if(this.getBalance() == 0){
            System.out.println(" insufficient funds");
            return false;
        }
        else {
            this.balance -= amount;
            return true;
        }
    }

    public void deductFees(){
        int no  = 0;
        for(int i = 0; i<transactions.size(); i++){
            if (( (transactions.get(i)).transactionType ==0 )|| ( (transactions.get(i)).transactionType ==1 )) {
                no ++;
                if(no >5 ){
                    withdraw(1.50);
                }

            }

        }

        transactionCount = 0;
    }
}
