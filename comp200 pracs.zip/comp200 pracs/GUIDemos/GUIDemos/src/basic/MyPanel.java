package basic;

import java.awt.*;

import javax.swing.JPanel;

public class MyPanel extends JPanel {

	public void paintComponent(Graphics g) {
		g.setFont(new Font(null,Font.BOLD,24));
		g.drawString("Hello COMP200", 20, 20);
		g.drawLine(25, 25, 100, 120);
	}
	
}
