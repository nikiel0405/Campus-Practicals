package basic;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;


public class BackGroundChanger extends JPanel {
	private JPanel canvas = new JPanel();

	public BackGroundChanger() {
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		
		JButton jbtChangeColor = new JButton("Change Color");
		jbtChangeColor.addActionListener(new ColorListener(){
									 @Override
									 public void actionPerformed(ActionEvent arg0) {
										 // TODO Auto-generated method stub
										 Graphics g = canvas.getGraphics();
										 int red = (int) (Math.random() * 255);
										 int green = (int) (Math.random() * 255);
										 int blue = (int) (Math.random() * 255);
										 Color newColor = new Color(red, green, blue);
										 canvas.setBackground(newColor);
									 }
								 }
		);

		buttonPanel.add(jbtChangeColor);
		
		this.setLayout(new BorderLayout());
		this.add(canvas,BorderLayout.CENTER);
		this.add(jbtChangeColor, BorderLayout.SOUTH);
		
	}
	
	class ColorListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			Graphics g = canvas.getGraphics();
			int red = (int)(Math.random() * 255);
			int green = (int)(Math.random() * 255);
			int blue = (int)(Math.random() * 255);
			Color newColor = new Color(red,green,blue);
			canvas.setBackground(newColor);
		}
		
	}
	
}
