package checkers;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Piece {
    public static final int  BLACK = 0;
    public static final int WHITE = 1;
    private boolean isCrown = false;
    private int color =0;
    private Image img = null;

    public Piece (int color) throws IOException {
        this.color = color;
        if (color == BLACK)
            img = ImageIO.read(new File("images/black.gif"));
        else
            img = ImageIO.read(new File("images/red.gif"));
    }

    public void draw(Graphics g, int x, int y){
        //g.drawImage();
    }


}
