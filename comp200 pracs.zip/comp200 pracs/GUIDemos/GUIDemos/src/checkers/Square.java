package checkers;

import java.awt.*;

public class Square {
    private int row;
    private int col;
    private Piece p = null;
    private int color = 0;
    private int size = 60;

    public Square(int color){

    }

    public void addPiece(Piece p){
        this.p = p;
    }
    public void removePiece(){
        p = null;
    }

    public void draw(Graphics g){

    }


}
