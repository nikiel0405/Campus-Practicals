package checkers;

import basic.MyPanel;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        JFrame myFrame = new JFrame();
        myFrame.setSize(400,400);
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setTitle("My First GUI");
        myFrame.add(new MyPanel());
        myFrame.setVisible(true);
    }
}
