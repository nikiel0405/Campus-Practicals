package checkers;

import javax.swing.*;

public class Board extends JPanel {


}
