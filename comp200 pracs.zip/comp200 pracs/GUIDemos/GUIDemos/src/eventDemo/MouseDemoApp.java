package eventDemo;

import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class MouseDemoApp extends JFrame {

	public MouseDemoApp()  {
		this.add(new MovableCirclePanel());
		
		
		setTitle("Event Demo");
	    setLocationRelativeTo(null); // Center the frame
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setSize(200, 200);
	    setVisible(true);
	}

	public static void main(String[] args){
		MouseDemoApp e = new MouseDemoApp();
	}
	
	
	

}
