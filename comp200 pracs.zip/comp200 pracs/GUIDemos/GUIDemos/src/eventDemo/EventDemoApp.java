package eventDemo;

import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.JFrame;


//This is the Launcher Application

public class EventDemoApp extends JFrame {

	public EventDemoApp()  {
		//just the object of class here 
		//to run it
		this.add(new BallControllerPanelIsListener());
		
		
		setTitle("Event Demo");
	    setLocationRelativeTo(null); // Center the frame
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setSize(200, 200);
	    setVisible(true);
	}

	public static void main(String[] args){
		EventDemoApp e = new EventDemoApp();
	}
	

}
