package eventDemo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

//Uses one Listener class
//activates on getSOurce
public class BallControllerOneListener extends JPanel {
	
	Ball canvas = new Ball();// creates ball object
	JButton jbtEnlarge = new JButton("Enlarge");// creates button
	   JButton jbtShrink = new JButton("Shrink"); // creates button
	   
	public BallControllerOneListener(){
	   JPanel panel = new JPanel(); // Use the panel to group buttons // creates panel
	   
	   ActionListener act = new ButtonListener();// creates an action listner
	   jbtEnlarge.addActionListener(act);// adds to button
	   
	   jbtShrink.addActionListener(act);// adds to button
	   
	   panel.add(jbtEnlarge);// add to panel
       panel.add(jbtShrink);// add to panel
       
       this.setLayout(new BorderLayout());
       this.add(canvas, BorderLayout.CENTER); // Add canvas to center
       this.add(panel, BorderLayout.SOUTH); // Add
	}
	
	
	class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource() == jbtEnlarge){
				canvas.enlarge();
			}
			else if (e.getSource() == jbtShrink){
				canvas.shrink();
			}
		}
		
		
	}
	
	
    
}
