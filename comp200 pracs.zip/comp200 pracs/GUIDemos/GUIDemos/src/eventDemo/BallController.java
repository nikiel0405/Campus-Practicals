package eventDemo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;


public class BallController extends JPanel {
	
	Ball canvas = new Ball();
	
	public BallController(){
	   JPanel panel = new JPanel(); // Use the panel to group buttons
	   JButton jbtEnlarge = new JButton("Enlarge");
	   JButton jbtShrink = new JButton("Shrink");
	   ActionListener act = new EnlargeListener();
	   jbtEnlarge.addActionListener(act);
	   
	   jbtShrink.addActionListener(new ShrinkListener());
	   
	   panel.add(jbtEnlarge);
       panel.add(jbtShrink);
       
       this.setLayout(new BorderLayout());
       this.add(canvas, BorderLayout.CENTER); // Add canvas to center
       this.add(panel, BorderLayout.SOUTH); // Add
	}
	 
	class EnlargeListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			canvas.enlarge();
		}
		
	}
	
	class ShrinkListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			canvas.shrink();
		}
		
	}
	
    
}
