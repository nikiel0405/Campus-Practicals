package eventDemo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

//Uses one Listener class
//activates on getSOurce
public class BallControllerPanelIsListener extends JPanel implements ActionListener {
	
	Ball canvas = new Ball();
	JButton jbtEnlarge = new JButton("Enlarge");
	   JButton jbtShrink = new JButton("Shrink");

	public BallControllerPanelIsListener(){
	   JPanel panel = new JPanel(); // Use the panel to group buttons
	   	   
	   jbtEnlarge.addActionListener(this);
	   
	   jbtShrink.addActionListener(this);
	   
	   panel.add(jbtEnlarge);
       panel.add(jbtShrink);
       
       this.setLayout(new BorderLayout());
       this.add(canvas, BorderLayout.CENTER); // Add canvas to center
       this.add(panel, BorderLayout.SOUTH); // Add
	}
	 
	

	@Override
	public void actionPerformed(ActionEvent e) {
	
					if (e.getSource() == jbtEnlarge){
						canvas.enlarge();
					}
					else if (e.getSource() == jbtShrink){
						canvas.shrink();
					}
	}
	
    
}
