package eventDemo;

import java.awt.Graphics;

import javax.swing.JPanel;

public class Ball extends JPanel {
	 private int radius = 5; // Default ball radius
	    
	    /** Enlarge the ball */
	    public void enlarge() {
	      radius += 1; 
	      repaint();
	    }
	    
	    /** Shrink the ball */
	    public void shrink() {
	      radius -= 1; 
	      repaint();
	    }
	    
	    @Override
	    protected void paintComponent(Graphics g) {
	      super.paintComponent(g);
	      g.drawOval(getWidth() / 2 - radius, getHeight() / 2 - radius, 
	        2 * radius, 2 * radius);
	    }
	  
}
