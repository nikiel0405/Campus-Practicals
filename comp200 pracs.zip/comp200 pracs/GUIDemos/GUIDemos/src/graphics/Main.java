package graphics;

import javax.swing.*;
import java.io.IOException;

public class Main {
    public static JFrame myFrame;

    public static void main(String[] args){
        myFrame = new JFrame();
        myFrame.setSize(400,400);
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setTitle("My First GUI");
        try {
            myFrame.add(new ImageCanvas());
        } catch (IOException e) {

        }

        myFrame.setVisible(true);
    }
}
