package graphics;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class ImageCanvas extends JPanel {
	Image myImage;
	
	public ImageCanvas() throws IOException {
		 myImage = ImageIO.read(new File("images/SOAF0001.GIF"));
	}
	public void paintComponent(Graphics g){
		g.drawImage(myImage, 0, 0, null);
		g.draw3DRect(5, 5, 100, 50, true);
		g.drawString("COMP200", 10, 10);
		g.setColor(Color.MAGENTA);
		g.fillOval(60, 60, 70, 75);
		
	}
	
}