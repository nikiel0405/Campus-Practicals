package com.company;

public class Main {

    public static void main(String[] args) {
	    ConnectFour ace = new ConnectFour();
        ace.print();
        ace.DropDisc(1,2);
        ace.DropDisc(1,3);
        ace.DropDisc(1,4);
        ace.DropDisc(-1,5);

        ace.DropDisc(1,2);
        ace.DropDisc(1,3);
        ace.DropDisc(-1,4);
        ace.DropDisc(1,5);

        ace.DropDisc(1,2);
        ace.DropDisc(-1,3);
        ace.DropDisc(1,4);
        ace.DropDisc(1,5);

        ace.DropDisc(-1,2);
        ace.DropDisc(1,3);
        ace.DropDisc(1,4);
        ace.DropDisc(1,5);
        ace.print();
        System.out.println(ace.Checkwin());
    }
}
