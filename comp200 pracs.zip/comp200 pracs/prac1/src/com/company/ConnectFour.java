package com.company;
public class ConnectFour {


    int[][] board = new int[6][7];

    ConnectFour() {
        for(int i = 0; i <6; i++){
            for(int j = 0 ; j <7 ;j++){
                board[i][j] = 0;
            }
        }
    }



    public void print() {
        for(int i = 0 ; i< 6; i++){
            System.out.print("|");

            for(int j = 0 ;j<7; j++){
                if(board[i][j] == 0){
                    System.out.print("      ");
                }
                else if(board[i][j]==1){
                    System.out.print("  R   ");
                }
                else if(board[i][j] ==-1){
                    System.out.print("  Y   ");

                }
                System.out.print("|");
            }
            System.out.println();
        }
    }

    public void DropDisc(int disc, int col){
        for(int i = 5; i >=0 ; i--){
            if(board[i][col] == 0){
                board[i][col] = disc;
                break;
            }
        }

    }
    public boolean isDraw(){
        boolean x = true;

        for(int i = 0; i<7; i++){

            if (board[0][i] != 0) {
                x = false;

            }
            else{
                x =true;

            }
        }
        return x;
    }

    public int Checkwin(){

        int win  = 0;

        int howr = 0;
        int howy = 0;
        for(int i = 0; i <6; i++){
            for(int j = 0 ;j<7; j++){
                if(board[i][j] == 1){
                    howr++;
                    howy= 0;
                    if(howr == 4){
                        win = 1;
                        break;
                    }
                }
                else if(board [i][j] == -1){

                    howy++;
                    howr = 0;
                    if(howy == 4) {
                        win = -1;
                        break;
                    }
                }
                else if(board[i][j] == 0){
                    howy = 0;
                    howr = 0;
                }
            }//ends second

        }//ends first

    // ends horizonatal
        howr = 0;
        howy = 0;
        for(int k = 0;k <7; k++){
            for(int l = 0 ; l<6 ;l++){
                if(board[l][k] == 1){
                    howr ++;
                    howy = 0;
                    if(howr == 4) {
                        win = 1;
                        break;
                    }
                }
                else if (board[l][k] == -1){
                    howy++;
                    howr = 0;
                    if(howy == 4){
                        win = -1;
                        break;
                    }

                }
                else if(board[l][k] == 0){
                    howy =0;
                    howr = 0;
                }
            }

        }
     //ends vertical

        howr = 0;
        howy = 0;
        for(int x = 0; x <6; x++){
            for(int y = 0; y<7; y++){
                if((x+3 <  6)&&(y+3 < 7)){
                    for(int t = 0; t < 4;t++){
                        if (board[x+t][y+t] == 1) {
                            howr ++;
                            howy = 0;
                            if(howr == 4) {
                                win = 1;
                                break;
                            }
                        }
                        else if(board[x+t][y+t] == -1){
                            howy++;
                            howr = 0;
                            if(howy == 4){
                                win = -1;
                                break;
                            }
                        }
                        else if(board[x +t][y+t] == 0){
                            howy = 0;
                            howr = 0;
                        }
                    }

                }
                else if((x - 3 >  0)&&(y+3 < 7)){
                    for(int t = 0; t < 4;t++){
                        if (board[x -t][y +t] == 1) {
                            howr ++;
                            howy = 0;
                            if(howr == 4) {
                                win = 1;
                                break;
                            }
                        }
                        else if(board[x -t][y +t] == -1){
                            howy++;
                            howr = 0;
                            if(howy == 4){
                                win = -1;
                                break;
                            }
                        }
                        else if(board[x -t][y+t] == 0){
                            howy = 0;
                            howr = 0;
                        }
                    }

                }


            }

        }



        return win;
    }


}
