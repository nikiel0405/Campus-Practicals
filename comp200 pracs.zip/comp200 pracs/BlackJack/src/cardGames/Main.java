package cardGames;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        JFrame table = new JFrame();
        table.setSize(400, 400);
        table.setLocationRelativeTo(null);
        table.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        table.setTitle("BlackJack");
        table.setLayout(new BorderLayout());
        BlackJackPanel blackJackPanel = new BlackJackPanel();
        table.add(blackJackPanel,BorderLayout.CENTER);
        table.setVisible(true);// write your code here// write your code hereJPanel buttonPanel = new JPanel();

        JPanel buttonPanel = new JPanel();

        buttonPanel.setBackground( new Color(220,200,180) );
        table.add(buttonPanel, BorderLayout.SOUTH);

        JButton hit = new JButton( "Hit!" );
        hit.addActionListener(blackJackPanel);
        buttonPanel.add(hit);

        JButton stand = new JButton( "Stand!" );
        stand.addActionListener(blackJackPanel);
        buttonPanel.add(stand);

        JButton newGame = new JButton( "New Game" );
        newGame.addActionListener(blackJackPanel);
        buttonPanel.add(newGame);



    }
}
