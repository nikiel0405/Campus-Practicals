/**
 * Apr 25, 2004
 * package blackJack
 * 
 */
package cardGames;

import javax.swing.JPanel;
import java.awt.event.*;
import cardGames.*;
import java.awt.*;
import java.util.*;

/**
 * Class BlackJackPanel
 * Apr 25, 2004
 * @author anban
 */
public class BlackJackPanel extends JPanel implements ActionListener {
	Deck deck = null;
	BlackJackHand dealerHand, playerHand;
	boolean gameInProgress = false;
	String message;

	BlackJackPanel() {
		setBackground(Color.green);
		setPreferredSize(new Dimension(640, 100));
		dealerHand = new BlackJackHand();
		playerHand = new BlackJackHand();
		doNewGame();

	}

	public void doNewGame() {
		if (gameInProgress) {
			message = "Finish game first!";
			repaint();
			return;
		}

		deck = new Deck();
		deck.shuffle();

		//clear the hands
		dealerHand.removeAll();
		playerHand.removeAll();

		//deal the cards
		//Dealers first card is face-down; all others are face-up
		Card c = deck.deal();
		c.flip();
		dealerHand.addCard(c);
		dealerHand.addCard(deck.deal());

		playerHand.addCard(deck.deal());
		playerHand.addCard(deck.deal());

		if (playerHand.value() == 21) {
			(dealerHand.getCard(0)).flip(); //flip dealer's first card

			if (dealerHand.value() != 21) {
				message = "BlackJack !!! You win";
			} else if (dealerHand.value() == 21) {
				message = "Tie!! Dealer also has BlackJack";
			}
			repaint();
		} else {
			message = "You have " + playerHand.value() + " . Hit or Stand!";
			gameInProgress = true;
		}

		repaint();

	}

	public void doHit() {

		if (!gameInProgress) {
			message = "Click New Game to start a new game.";
			repaint();
			return;
		}
		playerHand.addCard(deck.deal());
		if (playerHand.value() > 21) {
			message = "Bust!  Sorry, you lose.";
			gameInProgress = false;
		} else {
			message = "You have " + playerHand.value() + ".  Hit or Stand?";
		}
		repaint();
	}

	void doStand() {
		// This method is called when the user clicks the "Stand!" button.
		// Check whether a game is actually in progress.  If it is,
		// the game ends.  The dealer takes cards until the
		// dealer has more than 16 points.  Then the 
		// winner of the game is determined.
		if (gameInProgress == false) {
			message = "Click \"New Game\" to start a new game.";
			repaint();
			return;
		}
		(dealerHand.getCard(0)).flip(); //flip dealer's first card

		gameInProgress = false;
		while (dealerHand.value() <= 16)
			dealerHand.addCard(deck.deal());
		if (dealerHand.value() > 21)
			message =
				"You win!  Dealer has busted with " + dealerHand.value() + ".";
		else if (dealerHand.value() > playerHand.value())
			message =
				"Sorry, you lose, "
					+ dealerHand.value()
					+ " to "
					+ playerHand.value()
					+ ".";
		else if (dealerHand.value() == playerHand.value())
			message = "Tie!";
		else
			message =
				"You win, "
					+ playerHand.value()
					+ " to "
					+ dealerHand.value()
					+ "!";
		repaint();
	}

	public void actionPerformed(ActionEvent e) {

		String command = e.getActionCommand();
		if (command.equals("Hit!"))
			doHit();
		else if (command.equals("Stand!"))
			doStand();
		else if (command.equals("New Game"))
			doNewGame();
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		int horiz = 10;
		g.drawString("Dealer:", 20, 20);

		for(int i = 0; i < dealerHand.size();i++){
				dealerHand.getCard(i).draw(g,horiz,30);
				horiz += 20;
		}


		horiz = 10;
		g.drawString("Your Hand:", 20, 200);

		for(int i = 0; i < playerHand.size();i++){
			playerHand.getCard(i).draw(g,horiz,230);
			horiz += 20;
		}
		
		g.drawString(message, 20, 400);

	}

	public static void main(String[] args) {
	}
}
