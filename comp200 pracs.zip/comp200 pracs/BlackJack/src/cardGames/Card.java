 /**
 * Apr 9, 2004
 * package cardGames
 * 
 */

package cardGames;

import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;

/**
 * Class Card
 * Apr 9, 2004
 * @author anban
 */
public class Card {

	private int suit = 0;
	private int rank = 1; //1-13

	private boolean faceUp = true;

	private Image backImage = null;
	private Image frontImage = null;
	
	public Card(int suit, int rank) {
		this.suit = suit;
		this.rank = rank;
		try{
			backImage = ImageIO.read(new File("cardImages/b1fv.gif"));
			System.out.println(makeFileName());
			frontImage = ImageIO.read(new File(makeFileName()));
			
		} catch (IOException i){
			System.err.println("Image load error");
		}
	}

	public static void main(String[] args) {
		
		
		//System.out.println(c);
		
		class Panel extends JPanel {
			
			Card c;
			
			Panel(){
				c = new Card(1,13);
			}
			
			public void PanelTest(){
				
				//c = new Card(1,13);
				repaint();
				c.flip();
				repaint();
				
			}
			public void paintComponent(Graphics g){
				super.paintComponent(g);
				c.draw(g,20,10);
			}
		}
		
		JFrame frame = new JFrame();
				frame.setSize(new Dimension(500,500));
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Panel p = new Panel();
				frame.setContentPane(p);
				frame.show();
				p.PanelTest();
		
		
		
	}

	/**
	 * @return The rank (1 - 13)
	 */
	public int getRank() {
		return rank;
	}

	/**
	 * @return The suit of this card (0 - 3)
	 */
	public int getSuit() {
		return suit;
	}

	public void flip() {
		faceUp = !faceUp;
	}

	/**
	 * @return true if card is face up
	 */
	public boolean isFaceUp() {
		return faceUp;
	}

	/**
	 * @param b
	 */
	public void setFaceUp(boolean b) {
		faceUp = b;
	}

	public void draw(Graphics g, int x, int y) {
		if (faceUp)
			g.drawImage(frontImage,x,y,null);
		else
			g.drawImage(backImage,x,y,null);
	}

	
	private String makeFileName() {
		String s = "cardImages/";

		switch (suit) {
			case 0 :
				s += "h";
				break;
			case 1 :
				s += "d";
				break;
			case 2 :
				s += "c";
				break;
			case 3 :
				s += "s";
				break;
			default :
				break;
		}

		s += (new Integer(rank)).toString();

		s += ".gif";

		return s;
	}

	

	public String toString(){
		return suit + " " + rank;
	}

	
	

}
