/**
 * Apr 22, 2004
 * package cardGames
 * 
 */
package cardGames;

/**
 * Class CardNames
 * Apr 22, 2004
 * @author anban
 */
public interface CardNames {
	public static final int heart = 0;

	public static final int diamond = 1;

	public static final int club = 2;

	public static final int spade = 3;

	public static final int ace = 1;

	public static final int jack = 11;

	public static final int queen = 12;

	public static final int king = 13;

}