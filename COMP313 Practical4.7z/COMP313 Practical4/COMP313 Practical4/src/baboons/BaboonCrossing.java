package baboons;

import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * A solution to the baboon crossing problem.
 * 
 * @author vorsterl@ukzn.ac.za
 */
public final class BaboonCrossing {

	/**
	 * Entry point for the algorithm.
	 */
	public static void main(String[] args) {
		new BaboonCrossing();
	}

	/**
	 * Constructor for the algorithm. A pseudo-coin is tossed to decide which
	 * direction each of 100 baboons should approach from.
	 */
	public BaboonCrossing() {
		/*
		 * Seed RNG to current time for each run to be 'unique' - baboons will
		 * approach in a different order for each run.
		 * 
		 * Use a constant value for testing - this way baboons will approach in the same
		 * order for each run:
		 */
		Random rng = new Random(System.currentTimeMillis());
//		Random rng = new Random(0L);
		/*
		 * Create a thread of control for each baboon:
		 */
		for (int i = 0; i < 100; i++) {
			int coin = rng.nextInt() % 2;
			if (coin == 0) {
				new Thread(new Baboon(i, 0, multiplex, turnstile, rope, eastMutex,
				    eastCount)).start();
			} else {
				new Thread(new Baboon(i, 1, multiplex, turnstile, rope, westMutex,
				    westCount)).start();
			}
		}
	}

	/**
	 * Semaphore to control the number of baboons allowed on the rope at one time.
	 */
	private Semaphore multiplex = new Semaphore(5, true);
	/**
	 * Global turnstile for approaching the rope bridge.
	 */
	private Semaphore turnstile = new Semaphore(1, true);
	/**
	 * Mutex semaphore that represents the rope.
	 */
	private Semaphore rope = new Semaphore(1, true);
	/**
	 * Mutual exclusion semaphore to control single-file movement of all baboons
	 * travelling in the east direction.
	 */
	private Semaphore eastMutex = new Semaphore(1, true);
	/**
	 * Mutual exclusion semaphore to control single-file movement of all baboons
	 * travelling in the west direction.
	 */
	private Semaphore westMutex = new Semaphore(1, true);
	/**
	 * The number of baboons on the rope from the east.
	 */
	private AtomicInteger eastCount = new AtomicInteger(0);
	/**
	 * The number of baboons on the rope from the west.
	 */
	private AtomicInteger westCount = new AtomicInteger(0);
}
