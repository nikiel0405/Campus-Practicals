package baboons;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * A runnable task that represents a baboon crossing in one of two directions.
 * 
 * @author vorsterl@ukzn.ac.za
 */
final class Baboon implements Runnable {

  /**
   * Baboon task constructor.
   * 
   * @param tId
   *          the ID of the baboon.
   * @param dir
   *          the direction - 0=EAST 1=WEST
   * @param multiplex
   *          semaphore to control the number of baboons allowed on the rope at
   *          one time.
   * @param turnstile
   *          global turnstile for approaching the rope bridge.
   * @param rope
   *          mutex semaphore that represents the rope.
   * @param mutex
   *          mutual exclusion semaphore to control single-file movement of all
   *          baboons travelling in the same direction.
   * @param count
   *          the number of baboons on the rope.
   */
  Baboon(int tId, int dir, Semaphore multiplex, Semaphore turnstile,
      Semaphore rope, Semaphore mutex, AtomicInteger count) {
    this.tId = tId;
    this.direction = dir;
    this.multiplex = multiplex;
    this.turnstile = turnstile;
    this.rope = rope;
    this.mutex = mutex;
    this.count = count;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Runnable#run()
   */
  @Override
  public void run() {
    try {
      getOnRope();
      cross();
      getOffRope();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Method that represents a baboon attempting to climb onto the rope bridge.
   * 
   * @throws InterruptedException
   *           thrown if the baboon thread is interrupted while acquiring or
   *           releasing semaphores.
   */
  private void getOnRope() throws InterruptedException {
    turnstile.acquire();
    mutex.acquire();
    count.set(count.get() + 1);
    if (count.get() == 1) {
      rope.acquire();
      print("locked rope");
    }
    print("on rope");
    mutex.release();
    turnstile.release();
  }
  
  /**
   * Method that represents a baboon crossing the rope bridge.
   * 
   * @throws InterruptedException
   *           thrown if the baboon thread is interrupted while acquiring or
   *           releasing semaphores.
   */
  private void cross() throws InterruptedException {
    multiplex.acquire();
    print("crossing");
    Thread.sleep(1000);
    multiplex.release();
  }

  /**
   * Method that represents a baboon attempting to climb off the rope bridge.
   * 
   * @throws InterruptedException
   *           thrown if the baboon thread is interrupted while acquiring or
   *           releasing semaphores.
   */
  private void getOffRope() throws InterruptedException {
    mutex.acquire();
    count.set(count.get() - 1);
    if (count.get() == 0) {
      rope.release();
      print("unlocked rope");
    }
    print("off rope");
    mutex.release();
  }

  /**
   * Utility method for printing status messages to standard output. Direction,
   * ID, and rope count information is appended to the output.
   * 
   * @param msg
   *          the message to print.
   */
  private void print(String msg) {
    String dir = null;
    if (direction == 0) {
      dir = "EAST-";
    } else {
      dir = "\t\t\t\tWEST-";
    }
    System.out.println(dir + tId + "-" + count.get() + ": " + msg);
  }

  /**
   * 0=EAST 1=WEST
   */
  private int direction;
  /**
   * The ID of the baboon.
   */
  private int tId;
  /**
   * Semaphore to control the number of baboons allowed on the rope at one time.
   */
  private Semaphore multiplex = null;
  /**
   * Global turnstile for approaching the rope bridge.
   */
  private Semaphore turnstile = null;
  /**
   * Mutex semaphore that represents the rope.
   */
  private Semaphore rope = null;
  /**
   * Mutual exclusion semaphore to control single-file movement of all baboons
   * travelling in the same direction.
   */
  private Semaphore mutex = null;
  /**
   * The number of baboons on the rope.
   */
  private AtomicInteger count = null;
}