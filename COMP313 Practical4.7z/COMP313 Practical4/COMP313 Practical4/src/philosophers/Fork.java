package philosophers;

import java.util.concurrent.Semaphore;

/**
 * Forks are implemented as Semaphores. We encapsulate this so that the
 * implementation can be changed without affecting the rest of the program code.
 * 
 * @author vorsterl@ukzn.ac.za
 */
public final class Fork {

  /**
   * Fork constructor. Mutex is initialised here.
   */
  public Fork() {
    this.mutex = new Semaphore(1);
  }

  /**
   * Method for picking up a fork. This will block if the fork has been picked
   * up already.
   * 
   * @throws InterruptedException
   *           thrown if the philosopher thread is interrupted while blocking on
   *           the mutex.
   */
  public void pickUp() throws InterruptedException {
    mutex.acquire();
  }

  /**
   * Method for putting a a fork down. This will allow a waiting philosopher to
   * pick it up.
   */
  public void putDown() {
    mutex.release();
  }

  /**
   * The mutual exclusion semaphore.
   */
  private Semaphore mutex = null;
}
