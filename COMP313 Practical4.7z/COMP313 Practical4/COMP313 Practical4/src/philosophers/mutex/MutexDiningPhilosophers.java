package philosophers.mutex;

import philosophers.deadlocking.DeadlockingDiningPhilosophers;
import philosophers.deadlocking.DeadlockingPhilosopher;

/**
 * A solution to the dining philosophers problem that does not deadlock.
 * @author vorsterl@ukzn.ac.za
 */
public final class MutexDiningPhilosophers extends DeadlockingDiningPhilosophers {

  /**
   * MutexDiningPhilosophers constructor.
   * 
   * @param duration
   *          the time the simulation should run for.
   * @throws InterruptedException
   *           thrown if threads are interrupted.
   */
  public MutexDiningPhilosophers(int duration) throws InterruptedException {
    super(duration);
  }
  
  @Override
  protected void initialisePhilosophers() {
    philosophers = new DeadlockingPhilosopher[N];
    for (int i = 0; i < philosophers.length; i++) {
      philosophers[i] = new MutexPhilosopher(
      		i, forks[i], forks[(i + 1) % N], running  // insert additional parameters here
      );
    }
  }
  
  // insert your code here
}
