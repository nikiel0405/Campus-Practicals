package philosophers.mutex;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;

import philosophers.Fork;
import philosophers.deadlocking.DeadlockingPhilosopher;

/**
 * A philosopher that picks up both forks...?
 * @author vorsterl@ukzn.ac.za
 */
public final class MutexPhilosopher extends DeadlockingPhilosopher {

	Semaphore semaphore = new Semaphore(1);
	
	public MutexPhilosopher(int id, Fork left, Fork right, AtomicBoolean running ) {
	  super(id, left, right, running);
  }

	@Override
  protected void pickForksUp() throws InterruptedException {
		try {
			semaphore.acquire();
			leftFork.pickUp();
		    System.out.println(id + ": got left fork");
		    rightFork.pickUp();
		    System.out.println(id + ": got right fork");
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			semaphore.release();
		}  
	}

	@Override
  protected void putForksDown() throws InterruptedException {
		try {
			semaphore.acquire();
			leftFork.putDown();
		    System.out.println(id + ": drop left fork");
		    rightFork.putDown();
		    System.out.println(id + ": drop right fork");
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			semaphore.release();
		} 
		
	}

}
