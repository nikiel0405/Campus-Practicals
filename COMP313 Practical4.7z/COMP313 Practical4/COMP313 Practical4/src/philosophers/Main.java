package philosophers;

import java.io.IOException;

import philosophers.ambidextrous.AmbiDextrousDiningPhilosophers;
import philosophers.deadlocking.DeadlockingDiningPhilosophers;
import philosophers.mutex.MutexDiningPhilosophers;

public final class Main {

  /**
   * The entry point to the dining philosophers algorithm. Command-line 
   * arguments are parsed and the appropriate algorithm type is run.
   * 
   * @param args
   *          the name of the algorithm to run.
   *          the number of seconds to run the simulation for. This argument 
   *          is optional, and has a default value of 10 seconds.
   * @throws InterruptedException
   *           if a thread is interrupted unexpectedly.
   * @throws IOException 
   *           if the standard input fails.
   */
  public static void main(String[] args) 
      throws InterruptedException, IOException {
	  String[] bargs = {"Deadlocking", "200"};
	  args = bargs;

	  
	  if (args.length == 0) {
      System.out.println(
        "usage: java philosophers.Main <algorithm name> [<duration in sec>]"
        + "\nValid algorithms are: Deadlocking, AmbiDextrous, and Mutex."
      );
    } else {
      String type = args[0];
      int rtDur = args.length == 2 ? Integer.parseInt(args[1]) * 1000 : 10000;
      DeadlockingDiningPhilosophers algorithm = constructAlgorithm(type, rtDur);
      System.out.println("Press enter to begin:"); System.in.read();
      algorithm.go();
    }
  }

  /**
   * Utility factory function that knows how to construct algorithm instances. 
   * @param type 
   *          algorithm type.
   * @param rtDur 
   *          runtime duration.
   * @return 
   *          the algorithm instance.
   * @throws InterruptedException 
   *          thrown if threads are interrupted.
   */
  private static DeadlockingDiningPhilosophers constructAlgorithm(
    String type, int rtDur
  ) throws InterruptedException {
    DeadlockingDiningPhilosophers algorithm = null;
    if (type.equals("Deadlocking")) {
      algorithm = new DeadlockingDiningPhilosophers(rtDur);
    } else if (type.equals("AmbiDextrous")) {
      algorithm = new AmbiDextrousDiningPhilosophers(rtDur);
    } else if (type.equals("Mutex")) {
      algorithm = new MutexDiningPhilosophers(rtDur);
    } else {
      throw new IllegalArgumentException("Unknown algorithm type: " + type);
     
    }
    return algorithm;
  }
}
