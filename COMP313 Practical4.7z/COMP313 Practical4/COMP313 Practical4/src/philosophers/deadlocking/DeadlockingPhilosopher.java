package philosophers.deadlocking;

import java.util.concurrent.atomic.AtomicBoolean;

import philosophers.AbstractPhilosopher;
import philosophers.Fork;

/**
 * A philosopher that deadlocks by always picking up the left fork first. 
 * Subclasses should override the fork access methods to avoid the deadlock
 * resulting from a circular hold-and-wait condition.
 * @author vorsterl@ukzn.ac.za
 */
public class DeadlockingPhilosopher extends AbstractPhilosopher {

  /**
   * DeadlockingPhilosopher constructor.
   * 
   * @param id
   *          the index of the philosopher (0..N-1).
   * @param left
   *          the left fork.
   * @param right
   *          the right fork.
   * @param running
   *          flag to denote whether the philosopher thread should continue
   *          running its loop.
   */
	public DeadlockingPhilosopher(int id, Fork left, Fork right, AtomicBoolean running) {
    this.id = id;
    this.leftFork = left;
    this.rightFork = right;
    this.running = running;
  }

  /**
   * Method that represents the picking up of forks prior to eating.
   * 
   * @throws InterruptedException
   *           thrown if the philosopher thread is interrupted while locking a
   *           fork.
   */
  protected void pickForksUp() throws InterruptedException {
    leftFork.pickUp();
    System.out.println(id + ": got left fork");
    rightFork.pickUp();
    System.out.println(id + ": got right fork");
  }

  /**
   * Method that represents the putting down of forks prior to thinking.
   * 
   * @throws InterruptedException
   *           thrown if the philosopher thread is interrupted while locking a
   *           fork.
   */
  protected void putForksDown() throws InterruptedException {
    leftFork.putDown();
    System.out.println(id + ": drop left fork");
    rightFork.putDown();
    System.out.println(id + ": drop right fork");
  }
}
