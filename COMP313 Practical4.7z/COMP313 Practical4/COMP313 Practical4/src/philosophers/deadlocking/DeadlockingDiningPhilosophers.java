package philosophers.deadlocking;

import java.util.concurrent.atomic.AtomicBoolean;

import philosophers.Fork;

/**
 * A solution to the dining philosophers problem that might deadlock.
 * 
 * @author vorsterl@ukzn.ac.za
 */
public class DeadlockingDiningPhilosophers {
  
  /**
   * Number of philosophers.
   */
  protected static final int N = 2;

  /**
   * DeadlockingDiningPhilosophers constructor.
   * 
   * @param duration
   *          the time the simulation should run for.
   * @throws InterruptedException
   *           thrown if threads are interrupted.
   */
  public DeadlockingDiningPhilosophers(int duration) throws InterruptedException {
    this.runtimeDuration = duration;
    this.running = new AtomicBoolean(true);
    this.forks = new Fork[N];
    for (int i = 0; i < forks.length; i++) {
      forks[i] = new Fork();
    }
    initialisePhilosophers();
  }

  /**
   * Utility method for initialising philosophers. This method can be 
   * overridden by subclasses of the algorithm.
   */
  protected void initialisePhilosophers() {
    philosophers = new DeadlockingPhilosopher[N];
    for (int i = 0; i < philosophers.length; i++) {
      philosophers[i] = new DeadlockingPhilosopher(
        i, forks[i], forks[(i + 1) % N], running
      );
    }
  }

  /**
   * Runs the simulation.
   * 
   * @throws InterruptedException
   *           thrown if timer thread can't join main the thread.
   */
  public void go() throws InterruptedException {
    /*
     * Launch philosopher threads:
     */
    for (DeadlockingPhilosopher philosopher : philosophers) {
      new Thread(philosopher).start();
    }
    /*
     * Start timer to notify philosopher threads when to stop running:
     */
    Thread timerThread = new Thread(new Timer());
    timerThread.start();
    timerThread.join(); // connect timer to main thread
  }

  /**
   * An array of forks.
   */
  protected Fork[] forks = null;
  /**
   * An array of philosophers.
   */
  protected DeadlockingPhilosopher[] philosophers = null;
  /**
   * Flag to control philosopher thread loops.
   */
  protected AtomicBoolean running = null;
  /**
   * The duration that the simulation should run for.
   */
  private int runtimeDuration = -1;
  /**
   * Simple task to trigger the shutdown of the simulation. The running flag is
   * shared by all philosopher threads - when it is set to false, they will
   * terminate their loops cleanly.
   */
  class Timer implements Runnable {
    @Override
    public void run() {
      try {
        Thread.sleep(runtimeDuration);
        running.set(false);
        System.out.println("Stopping...");
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }
}
