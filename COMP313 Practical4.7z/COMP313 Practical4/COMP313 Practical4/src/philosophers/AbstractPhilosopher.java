package philosophers;

import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * A base-class for all philosopher task types. Subclasses need to provide the
 * logic for accessing forks.
 * 
 * Philosophers are subtasks (threads) that progress through an infinite loop of
 * thinking and eating. They require both forks to eat. When done, they put the
 * forks down and resume thinking.
 * 
 * @author vorsterl@ukzn.ac.za
 */
public abstract class AbstractPhilosopher implements Runnable {

	@Override
	public void run() {
		while (running.get()) {
			try {
				think();
				if (running.get()) { // if still running...
					pickForksUp();
					if (running.get())
						eat(); // if _still_ running...
					putForksDown();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Method that represents the picking up of forks prior to eating.
	 * 
	 * @throws InterruptedException
	 *           thrown if the philosopher thread is interrupted while locking a
	 *           fork.
	 */
	protected abstract void pickForksUp() throws InterruptedException;

	/**
	 * Method that represents the putting down of forks prior to thinking.
	 * 
	 * @throws InterruptedException
	 *           thrown if the philosopher thread is interrupted while locking a
	 *           fork.
	 */
	protected abstract void putForksDown() throws InterruptedException;

	/**
	 * Method that represents the time that the philosopher thinks for. It is a
	 * random value between 0-1000ms.
	 * 
	 * @throws InterruptedException
	 *           thrown if the philosopher thread is interrupted while thinking.
	 */
	private void think() throws InterruptedException {
		StringBuilder s = new StringBuilder(id + ": thinking for ");
		s.append(randomPause(1000L) + "ms");
		System.out.println(s.toString());
	}

	/**
	 * Method that represents the time that the philosopher eats for. It is a
	 * random value between 0-1000ms.
	 * 
	 * @throws InterruptedException
	 *           thrown if the philosopher thread is interrupted while eating.
	 */
	private void eat() throws InterruptedException {
		StringBuilder s = new StringBuilder(id + ": eating for ");
		s.append(randomWork(1000L) + "ms");
		System.out.println(s.toString());
	}

	/**
	 * Pauses the philosopher thread for a random bounded time period.
	 * 
	 * @param maxDuration
	 *          the maximum time to pause.
	 * @return the actual time spent pausing.
	 * @throws InterruptedException
	 *           thrown if the philosopher thread is interrupted while pausing.
	 */
	private long randomPause(long maxDuration) throws InterruptedException {
		long pauseDuration = (long) (rng.nextFloat() * maxDuration);
		Thread.sleep(pauseDuration);
		return pauseDuration;
	}

	/**
	 * Works the philosopher thread for a random bounded time period.
	 * 
	 * @param maxDuration
	 *          the maximum time to work.
	 * @return the actual time spent working.
	 * @throws InterruptedException
	 *           thrown if the philosopher thread is interrupted while working.
	 */
	private long randomWork(long maxDuration) throws InterruptedException {
		long workDuration = (long) (rng.nextFloat() * maxDuration);
		int[] data = new int[(int) workDuration];
		long tick = System.currentTimeMillis();
		long tock = System.currentTimeMillis();
		while ((tock - tick) < maxDuration) {
			for (int l = 0; l < workDuration; l++) {
				data[l] = (int) (System.currentTimeMillis()
				    * System.currentTimeMillis() % Long.MAX_VALUE);
			}
			tock = System.currentTimeMillis();
		}
		return workDuration;
	}

	/**
	 * Philosopher ID. Used to distinguish one from another.
	 */
	protected int id = -1;
	/**
	 * The fork on the left of the philosopher.
	 */
	protected Fork leftFork = null;
	/**
	 * The fork on the right of the philosopher.
	 */
	protected Fork rightFork = null;
	/**
	 * Global flag to denote whether philosopher threads should continue running
	 * or not.
	 */
	protected AtomicBoolean running = null;
	/**
	 * A random number generator for eating and sleeping durations.
	 */
	private Random rng = new Random(System.currentTimeMillis());
}