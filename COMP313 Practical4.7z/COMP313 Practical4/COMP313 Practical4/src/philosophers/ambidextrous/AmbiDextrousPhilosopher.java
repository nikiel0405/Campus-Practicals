package philosophers.ambidextrous;

import java.util.concurrent.atomic.AtomicBoolean;

import philosophers.Fork;
import philosophers.deadlocking.DeadlockingPhilosopher;

/**
 * An ambi-dextrous philosopher that picks up the left fork first if 
 * the id is even, and the right fork first if the id is odd.
 * @author vorsterl@ukzn.ac.za
 */
public final class AmbiDextrousPhilosopher extends DeadlockingPhilosopher {

  /**
   * Constructor for AmbiDextrousPhilosopher. 
   * @param id
   *          the index of the philosopher (0..N-1).
   * @param left
   *          the left fork.
   * @param right
   *          the right fork.
   * @param running
   *          flag to denote whether the philosopher thread should continue
   *          running its loop.
   */
	public AmbiDextrousPhilosopher(int id, Fork left, Fork right, AtomicBoolean running) {
    super(id, left, right, running);
  }

  /* (non-Javadoc)
   * @see philosophers.Philosopher#pickForksUp()
   */
  @Override
  protected void pickForksUp() throws InterruptedException {
    if (id % 2 == 0) { // even ID
      leftFork.pickUp();
      System.out.println(id + ": got left fork");
      rightFork.pickUp();
      System.out.println(id + ": got right fork");
    } else { // odd ID
      rightFork.pickUp();
      System.out.println(id + ": got right fork");
      leftFork.pickUp();
      System.out.println(id + ": got left fork");
    }
  }

  /* (non-Javadoc)
   * @see philosophers.Philosopher#putForksDown()
   */
  @Override
  protected void putForksDown() throws InterruptedException {
    if (id % 2 == 0) { // even ID
      rightFork.putDown();
      System.out.println(id + ": drop right fork");
      leftFork.putDown();
      System.out.println(id + ": drop left fork");
    } else { // odd ID
      leftFork.putDown();
      System.out.println(id + ": drop left fork");
      rightFork.putDown();
      System.out.println(id + ": drop right fork");
    }
  }
}
