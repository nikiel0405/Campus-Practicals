package philosophers.ambidextrous;

import philosophers.deadlocking.DeadlockingDiningPhilosophers;
import philosophers.deadlocking.DeadlockingPhilosopher;

/**
 * A solution to the dining philosophers problem that does not deadlock. 
 * Philosophers with even ID numbers pick up the left fork first and put
 * the left fork down last; philosophers with odd ID numbers pick up 
 * the right fork first and put the right fork down last.
 * @author vorsterl@ukzn.ac.za
 */
public final class AmbiDextrousDiningPhilosophers extends DeadlockingDiningPhilosophers {
  
  /**
   * AmbiDextrousDiningPhilosophers constructor.
   * 
   * @param duration
   *          the time the simulation should run for.
   * @throws InterruptedException
   *           thrown if threads are interrupted.
   */
	public AmbiDextrousDiningPhilosophers(int duration)
      throws InterruptedException {
    super(duration);
  }

  @Override
  protected void initialisePhilosophers() {
    philosophers = new DeadlockingPhilosopher[N];
    for (int i = 0; i < philosophers.length; i++) {
      philosophers[i] = new AmbiDextrousPhilosopher(
        i, forks[i], forks[(i + 1) % N], running
      );
    }
  }
}
