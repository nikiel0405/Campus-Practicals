package counter.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
//import org.junit.FixMethodOrder;
import org.junit.Test;
//import org.junit.runners.MethodSorters;

import counter.Counter;
import counter.CounterTask;
import counter.MutexCounter;

/**
 * Test cases for the CounterTask class.
 * 
 * @author vorsterl@ukzn.ac.za
 */
//@FixMethodOrder(MethodSorters.JVM)
public final class CounterTaskTest {

	/**
	 * The number of times a CounterTask should increment its Counter.
	 */
	private static final int NUM_LOOPS = 50000;

	/**
	 * This method is run once before each test case. It initialises a Counter
	 * instance to be used in each test case.
	 */
	@Before
	public void setUp() {
		this.counter = new MutexCounter();
	}

	/**
	 * Test the CounterTask constructor.
	 */
	@Test
	public void testConstructor() {
		CounterTask task = new CounterTask(counter, NUM_LOOPS);
		assertNotNull("Failed to create CounterTask instance.", task);
	}

	/**
	 * Test the CounterTask in a separate thread of execution.
	 */
	@Test
	public void testSingleThread() {
		// Wrap the task in a thread:
		Thread thread = new Thread(new CounterTask(counter, NUM_LOOPS));
		// Schedule the thread for execution:
		thread.start();
		// Wait until the thread dies:
		while (thread.isAlive()) {}
		assertEquals("Incorrect tally for single thread.", NUM_LOOPS,
		    counter.getTally());
	}

	/**
	 * Test three CounterTask instances, each in a separate thread of execution.
	 */
	@Test
	public void testThreeThreads() {
		// Wrap each task in its own thread:
		Thread thread1 = new Thread(new CounterTask(counter, NUM_LOOPS));
		Thread thread2 = new Thread(new CounterTask(counter, NUM_LOOPS));
		Thread thread3 = new Thread(new CounterTask(counter, NUM_LOOPS));
		// Schedule the threads for execution:
		thread1.start();
		thread2.start();
		thread3.start();
		// Wait until all threads die:
		while (thread1.isAlive() || thread2.isAlive() || thread3.isAlive()) {}
		assertEquals("Incorrect tally for three threads.", NUM_LOOPS * 3,
		    counter.getTally());
	}

	/**
	 * Run the 'testThreeThreads' case 1000 times - this is so that the race
	 * condition becomes apparent.
	 */
	@Test
	public void testThreeThreadsRepetitively() {
		for (int i = 0; i < 1000; i++) {
			testThreeThreads();
			setUp(); // new counter object for each iteration
		}
	}

	/**
	 * The Counter instance to use for each test case. 
	 */
	private Counter counter = null;
}
