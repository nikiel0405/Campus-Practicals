package counter.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

//import org.junit.FixMethodOrder;
import org.junit.Test;
//import org.junit.runners.MethodSorters;

import counter.Counter;

/**
 * Test cases for the Counter class.
 * @author vorsterl@ukzn.ac.za
 */
//@FixMethodOrder(MethodSorters.JVM)
public final class CounterTest {

	/**
	 * Test the constructor. 
	 */
	@Test
	public void testConstructor() {
		Counter counter = null;
		counter = new Counter();
		assertNotNull("Failed to create Counter instance.", counter);
	}

	/**
	 * Test the tally value after incrementing once.
	 */
	@Test
	public void testSingleIncrement() {
		Counter counter = new Counter();
		counter.increment();
		assertEquals("Incorrect tally after first increment.", 1, counter.getTally());		
	}

	/**
	 * Test the tally value after incrementing a number of times.
	 */
	@Test
	public void testManyIncrements() {
		final int NUM_LOOPS = Integer.MAX_VALUE;
		Counter counter = new Counter();
		for (int i = 0; i < NUM_LOOPS; i++) {
			counter.increment();  
    }
		assertEquals("Incorrect tally after many increments.", NUM_LOOPS, counter.getTally());		
	}
}
