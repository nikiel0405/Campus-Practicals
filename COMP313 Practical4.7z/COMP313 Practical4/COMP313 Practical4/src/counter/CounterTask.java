package counter;

/**
 * This class is responsible for incrementing a Counter object a specified
 * number of times as a runnable task. A task instance must be wrapped by a
 * thread object to execute the task in a separate thread of control.
 * 
 * @author vorsterl@ukzn.ac.za
 */
public final class CounterTask implements Runnable {

	/**
	 * The task constructor.
	 * @param counter - the Counter instance to be incremented.
	 * @param numLoops - the number of times to increment the Counter.
	 */
	public CounterTask(Counter counter, final int numLoops) {
		this.counter = counter;
		this.numLoops = numLoops;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		for (int i = 0; i < numLoops; i++) {
			this.counter.increment();
		}
	}

	/**
	 * The Counter instance to be incremented.
	 */
	private Counter counter = null;

	/**
	 * The number of times to increment the Counter.
	 */
	private final int numLoops;
}
