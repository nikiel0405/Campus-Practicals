package counter;

import java.util.concurrent.Semaphore;

/**
 * This class is a thread-safe extension of the Counter class.
 * 
 * @author 218038711
 */
public final class MutexCounter extends Counter {

	private Semaphore sem = new Semaphore(1);
	
	public void increment(){
		try{
			sem.acquire();
			super.increment();
		}catch (InterruptedException ex){
			System.out.println("Error");
		}finally{
			sem.release();
		}
	}
}
