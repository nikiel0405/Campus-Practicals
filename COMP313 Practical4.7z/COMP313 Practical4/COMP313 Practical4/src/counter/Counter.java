package counter;

/**
 * This class is responsible for maintaining a reference to a tally value, which
 * can be incremented and accessed via utility methods. All objects that need to
 * keep a tally of something can share an instance of this class.
 * 
 * Note: This class is not thread-safe.
 * 
 * @author vorsterl@ukzn.ac.za
 */
public class Counter {

	/**
	 * Default constructor - initialise the tally value to zero.
	 */
	public Counter() {
		this.tally = 0;
	}

	/**
	 * Increment the tally value.
	 */
	public void increment() {
		this.tally++;
	}

	/**
	 * Accessor method for the tally value.
	 * @return the tally.
	 */
	public int getTally() {
		return this.tally;
	}

	/**
	 * The tally value.
	 */
	private int tally;
}
